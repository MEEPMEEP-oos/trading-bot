"""Deployment and private maintenance checks; live officer data is never touched."""
import json
import os
import sqlite3
import sys
from pathlib import Path

import pytest
import yaml
from jsonschema import Draft202012Validator
from werkzeug.security import check_password_hash

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from server.app import create_app
from server.config import runtime_config
from server.launch import prepare_storage
from server.manage import backup_database, restore_database, set_password

HEADERS = {"X-Roster-Request": "1"}
PASSWORD = "Production-test-only-589!"
RECORD = {"name": "Deployment Officer", "badge_id": "DEPLOY-01", "rank": "Officer", "assignment": "Deployment Unit", "status": "On duty"}
ENV_KEYS = ["ROSTER_PUBLIC_VIEW", "ROSTER_ALLOWED_HOSTS", "ROSTER_ENV", "ROSTER_DB", "ROSTER_ADMIN_PASSWORD", "ROSTER_SEED_DEMO", "COOKIE_SECURE", "COOKIE_SAMESITE", "COOKIE_PARTITIONED", "FRAME_ANCESTORS"]


@pytest.fixture(autouse=True)
def clean_environment(monkeypatch):
    for key in ENV_KEYS:
        monkeypatch.delenv(key, raising=False)


@pytest.fixture
def production(tmp_path, monkeypatch):
    monkeypatch.setenv("ROSTER_ENV", "production")
    monkeypatch.setenv("ROSTER_ADMIN_PASSWORD", PASSWORD)
    app = create_app(tmp_path / "volume" / "roster.sqlite3")
    app.config["TESTING"] = True
    return app


def login(client, password=PASSWORD):
    return client.post("/api/auth/login", json={"password": password}, headers=HEADERS, base_url="https://localhost")


def test_production_starts_empty_and_preconfigures_password(production):
    client = production.test_client()
    assert client.get("/api/stats").status_code == 401  # directory data is private by default in production
    assert client.get("/api/auth/status").json == {"authenticated": False, "configured": True, "public_view": False}
    assert login(client).status_code == 200
    assert client.get("/api/stats", base_url="https://localhost").json["total"] == 0
    assert production.config["COOKIE_SECURE"] is True
    assert production.config["COOKIE_SAMESITE"] == "Lax"
    assert PASSWORD not in str(production.config)
    with sqlite3.connect(production.config["DATABASE"]) as db:
        hashed = db.execute("SELECT value FROM settings WHERE key='admin_password'").fetchone()[0]
    assert check_password_hash(hashed, PASSWORD)
    assert PASSWORD not in hashed
    assert Path(production.config["DATABASE"]).stat().st_mode & 0o777 == 0o600


def test_production_requires_password_before_first_start(tmp_path, monkeypatch):
    monkeypatch.setenv("ROSTER_ENV", "production")
    with pytest.raises(RuntimeError, match="Set ROSTER_ADMIN_PASSWORD"):
        create_app(tmp_path / "missing-secret.sqlite3")


@pytest.mark.parametrize("password", ["", "short", "elevenchars", " " * 12, "x" * 129, "aaaaaaaaaaaaaaaa", "password1234"])
def test_invalid_bootstrap_password_is_rejected(tmp_path, monkeypatch, password):
    monkeypatch.setenv("ROSTER_ENV", "production")
    monkeypatch.setenv("ROSTER_ADMIN_PASSWORD", password)
    with pytest.raises(RuntimeError, match="12–128"):
        create_app(tmp_path / "bad-secret.sqlite3")


def test_public_password_setup_is_disabled_in_production(production):
    response = production.test_client().post("/api/auth/setup", json={"password": "An-attacker-password"}, headers=HEADERS)
    assert response.status_code == 403
    assert login(production.test_client()).status_code == 200


def test_production_crud_and_persistence(production, monkeypatch):
    client = production.test_client()
    assert login(client).status_code == 200
    created = client.post("/api/officers", json=RECORD, headers=HEADERS, base_url="https://localhost")
    assert created.status_code == 201
    path = production.config["DATABASE"]
    # The bootstrap secret may be removed after initial setup. It is not a
    # dependency for subsequent starts with an existing administrator.
    monkeypatch.delenv("ROSTER_ADMIN_PASSWORD")
    restarted = create_app(path).test_client()
    assert login(restarted).status_code == 200
    assert restarted.get("/api/stats", base_url="https://localhost").json["total"] == 1
    assert restarted.get("/api/officers?q=DEPLOY-01", base_url="https://localhost").json["total"] == 1


def test_redeploy_does_not_overwrite_changed_password(production):
    client = production.test_client()
    assert login(client).status_code == 200
    change = client.post("/api/auth/password", json={"current_password": PASSWORD, "new_password": "Changed-password-296!"}, headers=HEADERS, base_url="https://localhost")
    assert change.status_code == 200
    # ROSTER_ADMIN_PASSWORD still contains the OLD bootstrap value.
    restarted = create_app(production.config["DATABASE"]).test_client()
    assert login(restarted, PASSWORD).status_code == 401
    assert login(restarted, "Changed-password-296!").status_code == 200


def test_existing_preview_data_survives_production_mode(tmp_path, monkeypatch):
    path = tmp_path / "existing.sqlite3"
    local = create_app(path)
    assert local.test_client().get("/api/stats").json["total"] == 24
    local.test_client().post("/api/auth/setup", json={"password": PASSWORD}, headers=HEADERS)
    monkeypatch.setenv("ROSTER_ENV", "production")
    deployed = create_app(path)
    assert deployed.test_client().get("/api/stats").status_code == 401
    session = deployed.test_client()
    assert login(session).status_code == 200
    assert session.get("/api/stats", base_url="https://localhost").json["total"] == 24


def test_production_security_headers(production):
    response = production.test_client().get("/")
    assert response.status_code == 200
    csp = response.headers["Content-Security-Policy"]
    assert "script-src 'self'" in csp
    assert "object-src 'none'" in csp
    assert "frame-ancestors 'self'" in csp
    assert response.headers["Strict-Transport-Security"] == "max-age=31536000"
    assert "camera=()" in response.headers["Permissions-Policy"]
    assert response.headers["X-Frame-Options"] == "SAMEORIGIN"
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["Cross-Origin-Opener-Policy"] == "same-origin"
    assert "upgrade-insecure-requests" in csp
    assert production.test_client().get("/api/health").headers["Cache-Control"] == "no-store"


def test_http_local_container_configuration(tmp_path, monkeypatch):
    monkeypatch.setenv("ROSTER_ENV", "production")
    monkeypatch.setenv("ROSTER_ADMIN_PASSWORD", PASSWORD)
    monkeypatch.setenv("COOKIE_SECURE", "false")
    app = create_app(tmp_path / "http-local.sqlite3")
    assert app.config["COOKIE_SECURE"] is False
    assert "Strict-Transport-Security" not in app.test_client().get("/").headers


def test_preview_does_not_get_frame_blocking_headers(tmp_path):
    client = create_app(tmp_path / "preview.sqlite3").test_client()
    assert "Content-Security-Policy" not in client.get("/").headers
    assert client.get("/api/auth/status").json["configured"] is False


@pytest.mark.parametrize("key,value", [
    ("ROSTER_ENV", "something-else"), ("COOKIE_SECURE", "sometimes"),
    ("COOKIE_PARTITIONED", "maybe"), ("ROSTER_SEED_DEMO", "maybe"),
    ("COOKIE_SAMESITE", "bad"), ("FRAME_ANCESTORS", "'self'; script-src *"),
    ("FRAME_ANCESTORS", "https://example.com\nX-Evil: true"),
])
def test_bad_configuration_fails_clearly(monkeypatch, key, value):
    monkeypatch.setenv(key, value)
    with pytest.raises(RuntimeError):
        runtime_config(ROOT)


@pytest.mark.parametrize("key,value", [("COOKIE_SAMESITE", "None"), ("COOKIE_PARTITIONED", "true")])
def test_cross_site_cookie_needs_secure_transport(monkeypatch, key, value):
    monkeypatch.setenv(key, value)
    with pytest.raises(RuntimeError, match="COOKIE_SECURE=true"):
        runtime_config(ROOT)


def test_environment_database_path_and_explicit_demo_opt_in(tmp_path, monkeypatch):
    path = tmp_path / "mounted" / "roster.sqlite3"
    monkeypatch.setenv("ROSTER_DB", str(path))
    monkeypatch.setenv("ROSTER_ENV", "production")
    monkeypatch.setenv("ROSTER_ADMIN_PASSWORD", PASSWORD)
    monkeypatch.setenv("ROSTER_SEED_DEMO", "true")
    app = create_app()
    assert app.config["DATABASE"] == str(path)
    client = app.test_client()
    assert login(client).status_code == 200
    assert client.get("/api/stats", base_url="https://localhost").json["total"] == 24


def test_backup_is_consistent_private_and_never_overwrites(production, tmp_path):
    client = production.test_client()
    assert login(client).status_code == 200
    assert client.post("/api/officers", json=RECORD, headers=HEADERS, base_url="https://localhost").status_code == 201
    database = Path(production.config["DATABASE"])
    backup = backup_database(database, tmp_path / "backups" / "snapshot.sqlite3")
    assert backup.stat().st_mode & 0o777 == 0o600
    with sqlite3.connect(backup) as db:
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert db.execute("SELECT COUNT(*) FROM officers").fetchone()[0] == 1
    with pytest.raises(ValueError, match="already exists"):
        backup_database(database, backup)
    with pytest.raises(ValueError, match="already exists"):
        backup_database(database, database)
    assert client.get("/api/stats", base_url="https://localhost").json["total"] == 1


def test_restore_preserves_credentials_and_revokes_sessions(production, tmp_path):
    client = production.test_client()
    assert login(client).status_code == 200
    assert client.post("/api/officers", json=RECORD, headers=HEADERS, base_url="https://localhost").status_code == 201
    source = Path(production.config["DATABASE"])
    snapshot = backup_database(source, tmp_path / "snapshot.sqlite3")
    restored = restore_database(snapshot, tmp_path / "restored.sqlite3")
    with sqlite3.connect(restored) as db:
        assert db.execute("SELECT COUNT(*) FROM sessions").fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM officers").fetchone()[0] == 1
    restarted = create_app(restored).test_client()
    assert login(restarted).status_code == 200
    with pytest.raises(ValueError, match="already exists"):
        restore_database(snapshot, source)


def test_private_password_reset_revokes_sessions(production):
    client = production.test_client()
    assert login(client).status_code == 200
    set_password(Path(production.config["DATABASE"]), "Owner-reset-password-037!")
    assert client.get("/api/auth/status").json["authenticated"] is False
    assert login(client, PASSWORD).status_code == 401
    assert login(client, "Owner-reset-password-037!").status_code == 200


def test_maintenance_rejects_wrong_databases_and_short_password(tmp_path):
    wrong = tmp_path / "wrong.sqlite3"
    with sqlite3.connect(wrong) as db:
        db.execute("CREATE TABLE unrelated (id INTEGER)")
    with pytest.raises(ValueError, match="not a Roster"):
        backup_database(wrong, tmp_path / "copy.sqlite3")
    with pytest.raises(ValueError, match="not found"):
        backup_database(tmp_path / "missing.sqlite3", tmp_path / "copy.sqlite3")
    with pytest.raises(ValueError, match="12 and 128"):
        set_password(wrong, "short")


def test_launcher_prepares_non_root_storage(tmp_path, monkeypatch):
    monkeypatch.setattr(os, "geteuid", lambda: 10001)
    database = tmp_path / "volume" / "roster.sqlite3"
    prepare_storage(database)
    assert database.parent.is_dir()


def test_launcher_root_stage_drops_privileges(tmp_path, monkeypatch):
    database = tmp_path / "volume" / "roster.sqlite3"
    database.parent.mkdir()
    database.touch()
    calls = []
    monkeypatch.setattr(os, "geteuid", lambda: 0)
    monkeypatch.setattr(os, "chown", lambda *args: calls.append(("chown", *args)))
    monkeypatch.setattr(os, "setgroups", lambda groups: calls.append(("groups", groups)))
    monkeypatch.setattr(os, "setgid", lambda gid: calls.append(("gid", gid)))
    monkeypatch.setattr(os, "setuid", lambda uid: calls.append(("uid", uid)))
    prepare_storage(database)
    assert ("groups", []) in calls
    assert ("gid", 10001) in calls and ("uid", 10001) in calls
    assert calls.index(("gid", 10001)) < calls.index(("uid", 10001))


def test_launcher_rejects_symlink_database(tmp_path):
    source = tmp_path / "actual.sqlite3"
    source.touch()
    link = tmp_path / "linked.sqlite3"
    link.symlink_to(source)
    with pytest.raises(RuntimeError, match="symbolic link"):
        prepare_storage(link)


@pytest.mark.parametrize("path", ["/roster.sqlite3", "/app/roster.sqlite3", "/etc/roster.sqlite3"])
def test_launcher_rejects_broad_data_directory(path):
    with pytest.raises(RuntimeError, match="dedicated"):
        prepare_storage(Path(path))


def test_render_blueprint_matches_official_schema():
    schema = json.loads((ROOT / "tests" / "schemas" / "render.schema.json").read_text())
    blueprint = yaml.safe_load((ROOT / "render.yaml").read_text())
    Draft202012Validator(schema).validate(blueprint)
    service = blueprint["services"][0]
    assert service["runtime"] == "docker" and service["numInstances"] == 1
    env = {item["key"]: item for item in service["envVars"]}
    assert env["ROSTER_ADMIN_PASSWORD"]["sync"] is False
    assert "value" not in env["ROSTER_ADMIN_PASSWORD"]
    assert env["ROSTER_DB"]["value"].startswith(service["disk"]["mountPath"] + "/")
    assert service["healthCheckPath"] == "/api/health"


def test_compose_maps_the_database_to_a_durable_volume():
    config = yaml.safe_load((ROOT / "compose.yaml").read_text())
    service = config["services"]["roster"]
    assert service["environment"]["ROSTER_DB"] == "/data/roster.sqlite3"
    assert "officer-data:/data" in service["volumes"]
    assert "officer-data" in config["volumes"]
    assert "${ROSTER_ADMIN_PASSWORD:?" in service["environment"]["ROSTER_ADMIN_PASSWORD"]
    assert service["read_only"] is True


def test_container_build_context_excludes_data_and_secrets():
    ignore = (ROOT / ".dockerignore").read_text()
    assert all(entry in ignore.splitlines() for entry in ["data", ".env", "*.sqlite3*", "node_modules", ".venv"])
    dockerfile = (ROOT / "Dockerfile").read_text()
    assert "FROM node:22-" in dockerfile
    assert "COPY --from=frontend /app/web ./web" in dockerfile
    assert 'CMD ["python", "-m", "server.launch"]' in dockerfile
    assert "COPY data" not in dockerfile and "COPY .env" not in dockerfile
    assert PASSWORD not in dockerfile


PRIVATE_ENDPOINTS = ["/api/officers", "/api/stats", "/api/activity", "/api/export/csv", "/api/export/xlsx"]


def test_production_private_by_default_and_public_view_opt_in(tmp_path, monkeypatch):
    monkeypatch.setenv("ROSTER_ENV", "production")
    monkeypatch.setenv("ROSTER_ADMIN_PASSWORD", PASSWORD)
    private = create_app(tmp_path / "private.sqlite3")
    assert private.config["PUBLIC_VIEW"] is False
    anonymous = private.test_client()
    for path in PRIVATE_ENDPOINTS:
        assert anonymous.get(path).status_code == 401, path
    assert anonymous.get("/api/health").status_code == 200
    assert anonymous.get("/api/auth/status").status_code == 200
    signed_in = private.test_client()
    assert login(signed_in).status_code == 200
    for path in PRIVATE_ENDPOINTS:
        assert signed_in.get(path, base_url="https://localhost").status_code == 200, path
    monkeypatch.setenv("ROSTER_PUBLIC_VIEW", "true")
    public = create_app(tmp_path / "public.sqlite3")
    assert public.config["PUBLIC_VIEW"] is True
    assert public.test_client().get("/api/officers").status_code == 200


def test_allowed_hosts_rejects_foreign_host_header(tmp_path, monkeypatch):
    monkeypatch.setenv("ROSTER_ALLOWED_HOSTS", "roster.example.com")
    app = create_app(tmp_path / "hosts.sqlite3")
    client = app.test_client()
    assert client.get("/api/health", base_url="https://roster.example.com").status_code == 200
    assert client.get("/api/health", base_url="https://evil.example.net").status_code == 400
