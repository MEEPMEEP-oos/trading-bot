import { chromium } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import fs from "node:fs/promises";

const base = process.env.APP_URL || "http://127.0.0.1:3000";
const browser = await chromium.launch({ args: ["--no-sandbox"] });
const context = await browser.newContext({
  viewport: { width: 1440, height: 1080 },
  reducedMotion: "reduce",
});
const page = await context.newPage();
const audits = [];
await fs.mkdir("tests/artifacts", { recursive: true });
async function audit(view) {
  // Audit the settled UI, not an intermediate frame of an entrance/exit fade.
  await page.waitForFunction(() =>
    [
      ...document.querySelectorAll(
        ".overview-content,.export-page,.activity-panel,.directory-section,.dialog-backdrop,.dialog,.dropdown-menu,.stat-card,.toast",
      ),
    ].every((el) => getComputedStyle(el).opacity === "1"),
  );
  const result = await new AxeBuilder({ page }).analyze();
  audits.push({ view, violations: result.violations });
  console.log(
    view,
    result.violations.length
      ? result.violations.map((v) => ({
          id: v.id,
          count: v.nodes.length,
          targets: v.nodes.slice(0, 8).map((n) => n.target),
        }))
      : "PASS — no automatic accessibility violations",
  );
}
try {
  await page.goto(base, { waitUntil: "networkidle" });
  await audit("Directory");
  await page.screenshot({
    path: "tests/artifacts/directory-desktop.png",
    fullPage: true,
    animations: "disabled",
  });
  await page.getByRole("button", { name: "Admin access", exact: true }).click();
  await audit("Admin access");
  await page.screenshot({
    path: "tests/artifacts/admin-access.png",
    animations: "disabled",
  });
  await page.keyboard.press("Escape");
  for (const view of ["Overview", "Activity log", "Exports"]) {
    await page.getByRole("button", { name: view, exact: true }).click();
    await page.waitForLoadState("networkidle");
    await audit(view);
  }
  await page
    .getByRole("button", { name: "Back to directory", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Filter officers", exact: true })
    .click();
  await audit("Filters");
  await page.keyboard.press("Escape");
  await page.locator(".officer-name").first().click();
  await audit("Officer profile");
  await page.keyboard.press("Escape");
  await page
    .getByRole("button", { name: "A little help", exact: true })
    .click();
  await audit("Help");
  await page.keyboard.press("Escape");
  const mobileContext = await browser.newContext({
    viewport: { width: 390, height: 844 },
    reducedMotion: "reduce",
  });
  const mobile = await mobileContext.newPage();
  await mobile.goto(base, { waitUntil: "networkidle" });
  await mobile.screenshot({
    path: "tests/artifacts/directory-mobile.png",
    fullPage: true,
    animations: "disabled",
  });
  const mobileAudit = await new AxeBuilder({ page: mobile }).analyze();
  audits.push({ view: "Mobile directory", violations: mobileAudit.violations });
  console.log(
    "Mobile directory",
    mobileAudit.violations.map((v) => ({ id: v.id, count: v.nodes.length })),
  );
  console.log(
    "Mobile document width:",
    await mobile.evaluate(() => document.documentElement.scrollWidth),
  );
} finally {
  await fs.writeFile(
    "tests/artifacts/accessibility.json",
    JSON.stringify(audits, null, 2),
  );
  const violations = audits.reduce((sum, a) => sum + a.violations.length, 0);
  console.log(
    `${audits.length} screens audited. ${violations} automatic violations.`,
  );
  process.exitCode = violations ? 1 : 0;
  await browser.close();
}
