"""Native/container smoke check. Use ONLY an isolated disposable database.

First invocation creates a record. Restart the service on the same volume,
then pass --after-restart to verify persistence, editing, exports, and deletion.
"""
import argparse
import csv
import http.cookiejar
import io
import json
import os
import sys
import urllib.error
import urllib.request
from urllib.parse import urlparse

from openpyxl import load_workbook

parser = argparse.ArgumentParser()
parser.add_argument("--base-url", default="http://127.0.0.1:3080")
parser.add_argument("--after-restart", action="store_true")
args = parser.parse_args()
password = os.environ.get("PRODUCTION_TEST_PASSWORD")
if not password:
    parser.error("Set PRODUCTION_TEST_PASSWORD for the isolated test workspace.")
base = args.base_url.rstrip("/")
origin = f"{urlparse(base).scheme}://{urlparse(base).netloc}"
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))


def request(path, method="GET", body=None):
    headers = {"X-Roster-Request": "1", "Origin": origin}
    if body is not None:
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(base + path, data=json.dumps(body).encode() if body is not None else None, headers=headers, method=method)
    with opener.open(req, timeout=20) as response:
        data = response.read()
        return json.loads(data) if "application/json" in response.headers.get("Content-Type", "") else data


health = request("/api/health")
assert health["database"] == "connected" and health["persistent"]
assert request("/api/auth/status")["configured"]
request("/api/auth/login", "POST", {"password": password})
assert request("/api/auth/status")["authenticated"]
record = {"name": "Container Persistence Check", "badge_id": "CONTAINER-CHECK", "rank": "Officer", "assignment": "Deployment Verification", "status": "On duty", "email": "container-check@example.com", "notes": "Disposable deployment smoke-test record."}
if not args.after_restart:
    assert request("/api/stats")["total"] == 0, "Use a FRESH isolated production test database."
    created = request("/api/officers", "POST", record)
    assert created["badge_id"] == record["badge_id"]
    assert request("/api/stats")["total"] == 1
    print("PASS production bootstrap, protected create, and persistent-volume write. Restart the test service now.")
else:
    found = request("/api/officers?q=CONTAINER-CHECK")
    assert found["total"] == 1, "The record did not survive the restart."
    officer = found["officers"][0]
    changed = request(f"/api/officers/{officer['id']}", "PUT", {**officer, "status": "Off duty"})
    assert changed["status"] == "Off duty"
    csv_rows = list(csv.DictReader(io.StringIO(request("/api/export/csv?q=CONTAINER-CHECK").decode("utf-8-sig"))))
    assert len(csv_rows) == 1 and csv_rows[0]["Status"] == "Off duty"
    sheet = load_workbook(io.BytesIO(request("/api/export/xlsx?q=CONTAINER-CHECK"))).active
    assert sheet.max_row == 2 and sheet["E2"].value == "Off duty"
    request(f"/api/officers/{officer['id']}", "DELETE")
    assert request("/api/stats")["total"] == 0
    print("PASS actual server restart persistence, protected edit/delete, CSV, and genuine Excel export.")
