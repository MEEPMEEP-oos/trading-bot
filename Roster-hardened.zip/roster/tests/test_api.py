"""Integration tests use isolated temporary databases, never the live workspace."""
import csv
import io
import sqlite3
import sys
from pathlib import Path

import pytest
from openpyxl import load_workbook

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from server.app import create_app, FIELDS

HEADERS = {"X-Roster-Request": "1"}
PASSWORD = "Testing-only-password-478!"
RECORD = {"name": "Test Officer", "badge_id": "TEST-9001", "rank": "Sergeant", "assignment": "Testing Unit", "status": "On duty", "email": "test@example.com", "phone": "+1 555 0100", "joined_date": "2025-05-20", "notes": "Integration test record."}


@pytest.fixture
def app(tmp_path):
    app = create_app(tmp_path / "test.sqlite3")
    app.config["TESTING"] = True
    return app


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def admin(client):
    response = client.post("/api/auth/setup", json={"password": PASSWORD}, headers=HEADERS)
    assert response.status_code == 200
    return client


def add(client, record=None):
    return client.post("/api/officers", json=record or RECORD, headers=HEADERS)


def test_database_health(client):
    assert client.get("/api/health").json == {"status": "ok", "database": "connected", "storage": "SQLite", "persistent": True}


def test_seed_data_and_stats(client):
    stats = client.get("/api/stats").json
    assert (stats["total"], stats["on_duty"], stats["off_duty"], stats["on_leave"], stats["sample_count"]) == (24, 16, 6, 2, 24)
    assert sum(a["count"] for a in stats["assignments"]) == 24
    data = client.get("/api/officers").json
    assert len(data["officers"]) == 8
    assert data["pages"] == 3


def test_public_read_and_protected_mutations(client):
    officer = client.get("/api/officers").json["officers"][0]
    assert client.get(f"/api/officers/{officer['id']}").status_code == 200
    assert client.get("/api/activity").status_code == 200
    assert add(client).status_code == 401
    assert client.put(f"/api/officers/{officer['id']}", json=RECORD, headers=HEADERS).status_code == 401
    assert client.delete(f"/api/officers/{officer['id']}", headers=HEADERS).status_code == 401
    assert client.post("/api/officers/bulk-delete", json={"ids": [officer['id']]}, headers=HEADERS).status_code == 401


def test_password_setup_and_hashing(client, app):
    assert client.get("/api/auth/status").json == {"authenticated": False, "configured": False, "public_view": True}
    assert client.post("/api/auth/setup", json={"password": "short"}, headers=HEADERS).status_code == 400
    response = client.post("/api/auth/setup", json={"password": PASSWORD}, headers=HEADERS)
    assert response.status_code == 200
    assert "HttpOnly" in response.headers["Set-Cookie"]
    assert "SameSite=Lax" in response.headers["Set-Cookie"]
    assert client.get("/api/auth/status").json["authenticated"] is True
    with sqlite3.connect(app.config["DATABASE"]) as db:
        saved = db.execute("SELECT value FROM settings WHERE key='admin_password'").fetchone()[0]
        assert saved != PASSWORD and PASSWORD not in saved
    assert client.post("/api/auth/setup", json={"password": "another-password"}, headers=HEADERS).status_code == 409


def test_login_logout(admin):
    assert admin.post("/api/auth/logout", json={}, headers=HEADERS).status_code == 200
    assert admin.get("/api/auth/status").json["authenticated"] is False
    assert admin.post("/api/auth/login", json={"password": "incorrect"}, headers=HEADERS).status_code == 401
    assert admin.post("/api/auth/login", json={"password": PASSWORD}, headers=HEADERS).status_code == 200
    assert add(admin).status_code == 201


def test_crud_and_audit(admin):
    created = add(admin)
    assert created.status_code == 201
    officer = created.json
    assert officer["name"] == RECORD["name"] and officer["is_demo"] == 0
    edited = admin.put(f"/api/officers/{officer['id']}", json={**officer, "name": "Updated Officer", "status": "On leave"}, headers=HEADERS)
    assert edited.status_code == 200
    assert admin.get(f"/api/officers/{officer['id']}").json["status"] == "On leave"
    assert admin.delete(f"/api/officers/{officer['id']}", headers=HEADERS).status_code == 200
    assert admin.get(f"/api/officers/{officer['id']}").status_code == 404
    assert admin.get("/api/stats").json["total"] == 24
    actions = [a["action"] for a in admin.get("/api/activity").json["items"]]
    assert all(a in actions for a in ["created", "updated", "deleted"])


def test_duplicate_badge_is_rejected(admin):
    assert add(admin).status_code == 201
    assert add(admin, {**RECORD, "name": "Another Officer", "badge_id": "test-9001"}).status_code == 409
    second = add(admin, {**RECORD, "badge_id": "TEST-9002"}).json
    assert admin.put(f"/api/officers/{second['id']}", json={**second, "badge_id": "TEST-9001"}, headers=HEADERS).status_code == 409


@pytest.mark.parametrize("field,value", [
    ("name", ""), ("badge_id", "!bad$"), ("rank", "Unknown"), ("assignment", ""),
    ("status", "Unknown"), ("email", "invalid-email"), ("joined_date", "2025-02-30"),
    ("name", 123), ("notes", "a" * 2001),
])
def test_validation(admin, field, value):
    assert add(admin, {**RECORD, field: value}).status_code == 400


def test_search_filters_and_pagination(client):
    assert client.get("/api/officers?q=aiden").json["officers"][0]["name"] == "Aiden Brooks"
    assert client.get("/api/officers?q=OF-1042").json["total"] == 1
    assert client.get("/api/officers?q=example.com").json["total"] == 24
    assert client.get("/api/officers?q=%25").json["total"] == 0
    filtered = client.get("/api/officers?status=On+duty&rank=Officer&assignment=Patrol+Operations").json
    assert filtered["total"] > 0
    assert all(r["status"] == "On duty" and r["rank"] == "Officer" and r["assignment"] == "Patrol Operations" for r in filtered["officers"])
    first = client.get("/api/officers?page=1&page_size=8").json
    second = client.get("/api/officers?page=2&page_size=8").json
    assert not set(r["id"] for r in first["officers"]) & set(r["id"] for r in second["officers"])
    assert client.get("/api/officers?page=999").json["page"] == 3


@pytest.mark.parametrize("column", ["name", "badge_id", "rank", "assignment", "status"])
def test_every_column_sorts_both_directions(client, column):
    for direction in ["asc", "desc"]:
        rows = client.get(f"/api/officers?sort={column}&direction={direction}&page_size=100").json["officers"]
        values = [r[column].lower() for r in rows]
        assert values == sorted(values, reverse=direction == "desc")


def test_bad_sort_and_injection_are_rejected(client):
    assert client.get("/api/officers?sort=name;DROP+TABLE+officers").status_code == 400
    assert client.get("/api/officers?direction=sideways").status_code == 400
    assert client.get("/api/officers?status=missing").status_code == 400
    assert client.get("/api/officers?page=not-a-number").status_code == 400
    assert client.get("/api/officers?q=%27+OR+1%3D1--").json["total"] == 0
    assert client.get("/api/stats").json["total"] == 24


def test_csv_export_all_matching_records(client):
    response = client.get("/api/export/csv?sort=name&direction=desc")
    assert response.status_code == 200
    assert ".csv" in response.headers["Content-Disposition"]
    rows = list(csv.reader(io.StringIO(response.data.decode("utf-8-sig"))))
    assert len(rows) == 25 and len(rows[0]) == 9
    assert rows[1][0] == "Zoe Williams"
    filtered = client.get("/api/export/csv?status=On+duty")
    records = list(csv.DictReader(io.StringIO(filtered.data.decode("utf-8-sig"))))
    assert len(records) == 16
    assert all(r["Status"] == "On duty" for r in records)


def test_excel_export_is_valid_workbook(client):
    response = client.get("/api/export/xlsx?assignment=Investigations&direction=asc")
    assert response.status_code == 200
    assert response.mimetype == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    workbook = load_workbook(io.BytesIO(response.data))
    sheet = workbook["Officers"]
    count = client.get("/api/officers?assignment=Investigations").json["total"]
    assert sheet.max_row == count + 1 and sheet.max_column == 9
    assert sheet.freeze_panes == "A2"
    assert all(row[3].value == "Investigations" for row in list(sheet.rows)[1:])
    assert "OfficerDirectory" in sheet.tables


def test_empty_exports_and_safe_spreadsheet_cells(admin):
    empty = admin.get("/api/export/xlsx?q=nobody-matches-this")
    assert load_workbook(io.BytesIO(empty.data)).active.max_row == 1
    assert add(admin, {**RECORD, "notes": '=HYPERLINK("https://example.com")'}).status_code == 201
    exported = admin.get("/api/export/csv?q=TEST-9001")
    rows = list(csv.reader(io.StringIO(exported.data.decode("utf-8-sig"))))
    assert rows[1][-1].startswith("'=")
    excel = load_workbook(io.BytesIO(admin.get("/api/export/xlsx?q=TEST-9001").data)).active
    assert excel["I2"].data_type == "s"
    assert excel["I2"].value.startswith("=")


def test_bulk_remove(admin):
    ids = [r["id"] for r in admin.get("/api/officers").json["officers"][:3]]
    response = admin.post("/api/officers/bulk-delete", json={"ids": ids}, headers=HEADERS)
    assert response.json["deleted"] == 3
    assert admin.get("/api/stats").json["total"] == 21
    assert admin.post("/api/officers/bulk-delete", json={"ids": []}, headers=HEADERS).status_code == 400


def test_optimistic_concurrency(admin):
    original = add(admin).json
    assert admin.put(f"/api/officers/{original['id']}", json={**original, "name": "Latest Version"}, headers=HEADERS).status_code == 200
    stale = admin.put(f"/api/officers/{original['id']}", json={**original, "name": "Stale Version"}, headers=HEADERS)
    assert stale.status_code == 409
    assert admin.get(f"/api/officers/{original['id']}").json["name"] == "Latest Version"


def test_csrf_protection_and_same_origin(admin):
    assert admin.post("/api/officers", json=RECORD).status_code == 403
    assert admin.post("/api/officers", json=RECORD, headers={**HEADERS, "Origin": "https://malicious.example"}).status_code == 403
    assert admin.post("/api/officers", json=RECORD, headers={**HEADERS, "Origin": "http://localhost"}).status_code == 201


def test_expired_session(admin, app):
    with sqlite3.connect(app.config["DATABASE"]) as db:
        db.execute("UPDATE sessions SET expires_at=0")
    assert admin.get("/api/auth/status").json["authenticated"] is False
    assert add(admin).status_code == 401


def test_password_change_revokes_other_sessions(admin, app):
    second = app.test_client()
    assert second.post("/api/auth/login", json={"password": PASSWORD}, headers=HEADERS).status_code == 200
    assert admin.post("/api/auth/password", json={"current_password": "wrong", "new_password": "Updated-password-123"}, headers=HEADERS).status_code == 401
    assert admin.post("/api/auth/password", json={"current_password": PASSWORD, "new_password": "Updated-password-123"}, headers=HEADERS).status_code == 200
    assert second.get("/api/auth/status").json["authenticated"] is False
    assert second.post("/api/auth/login", json={"password": PASSWORD}, headers=HEADERS).status_code == 401
    assert second.post("/api/auth/login", json={"password": "Updated-password-123"}, headers=HEADERS).status_code == 200


def test_login_rate_limit(admin):
    for _ in range(10):
        assert admin.post("/api/auth/login", json={"password": "wrong"}, headers=HEADERS).status_code == 401
    assert admin.post("/api/auth/login", json={"password": PASSWORD}, headers=HEADERS).status_code == 429


def test_persistence_after_app_restart(tmp_path):
    path = tmp_path / "persistent.sqlite3"
    first = create_app(path).test_client()
    assert first.post("/api/auth/setup", json={"password": PASSWORD}, headers=HEADERS).status_code == 200
    created = add(first).json
    first.put(f"/api/officers/{created['id']}", json={**created, "name": "Persisted Officer"}, headers=HEADERS)
    restarted = create_app(path).test_client()
    assert restarted.get("/api/officers?q=Persisted+Officer").json["total"] == 1
    assert restarted.get("/api/stats").json["total"] == 25
    assert restarted.get("/api/auth/status").json == {"authenticated": False, "configured": True, "public_view": True}
    assert restarted.post("/api/auth/login", json={"password": PASSWORD}, headers=HEADERS).status_code == 200
    assert restarted.delete(f"/api/officers/{created['id']}", headers=HEADERS).status_code == 200
    again = create_app(path).test_client()
    assert again.get("/api/stats").json["total"] == 24
    assert again.get(f"/api/officers/{created['id']}").status_code == 404


def test_empty_workspace_is_not_reseeded(tmp_path):
    path = tmp_path / "empty.sqlite3"
    app = create_app(path, seed=False)
    assert app.test_client().get("/api/stats").json["total"] == 0
    restarted = create_app(path, seed=True)
    assert restarted.test_client().get("/api/stats").json["total"] == 0


def test_secure_partitioned_cookie_for_embedded_https_preview(client, app):
    app.config.update(COOKIE_SECURE=True, COOKIE_SAMESITE="None", COOKIE_PARTITIONED=True)
    response = client.post("/api/auth/setup", json={"password": PASSWORD}, headers=HEADERS)
    cookie = response.headers["Set-Cookie"]
    assert all(flag in cookie for flag in ["Secure", "HttpOnly", "SameSite=None", "Partitioned"])
    logout = client.post("/api/auth/logout", json={}, headers=HEADERS)
    assert "Partitioned" in logout.headers["Set-Cookie"]


def test_unknown_api_route_returns_json(client):
    response = client.get("/api/unknown-endpoint")
    assert response.status_code == 404 and response.is_json


def test_malformed_json_bodies_never_cause_server_errors(admin):
    for body in ([1], "text", 5, None):
        for path in ["/api/auth/login", "/api/auth/password", "/api/officers", "/api/officers/bulk-delete"]:
            assert admin.post(path, json=body, headers=HEADERS).status_code in {400, 401, 409, 415}, (path, body)
    assert admin.post("/api/auth/login", data="{not json", content_type="application/json", headers=HEADERS).status_code in {400, 401}


def test_weak_passwords_are_rejected(client):
    for weak in ["short", "elevenchars", "password1234", "aaaaaaaaaaaaaaaa", " " * 14]:
        assert client.post("/api/auth/setup", json={"password": weak}, headers=HEADERS).status_code == 400, weak


def test_contact_fields_reject_header_injection_and_control_characters(admin):
    for field, value in [("email", "a@b.co?bcc=x@y.zz"), ("email", "a b@c.de"), ("phone", "javascript:alert(1)"), ("name", "Bad\nName"), ("notes", "bell\x07")]:
        assert add(admin, {**RECORD, field: value}).status_code == 400, (field, value)
    assert add(admin, {**RECORD, "phone": "+1 (555) 010-0100 x22", "notes": "Line one\nLine two"}).status_code == 201


def test_general_api_rate_limit_and_retry_after(client):
    from server import app as app_module
    original = dict(app_module.RATE_LIMITS)
    app_module.RATE_LIMITS["api"] = (5, 60)
    try:
        codes = [client.get("/api/health").status_code for _ in range(7)]
    finally:
        app_module.RATE_LIMITS.update(original)
    assert codes[:5] == [200] * 5 and codes[5:] == [429, 429]


def test_write_and_export_rate_limits(admin):
    from server import app as app_module
    original = dict(app_module.RATE_LIMITS)
    app_module.RATE_LIMITS["export"] = (3, 60)
    try:
        codes = [admin.get("/api/export/csv").status_code for _ in range(4)]
    finally:
        app_module.RATE_LIMITS.update(original)
    assert codes == [200, 200, 200, 429]


def test_password_change_guessing_is_throttled(admin):
    for _ in range(10):
        assert admin.post("/api/auth/password", json={"current_password": "wrong", "new_password": "A-brand-new-password-1"}, headers=HEADERS).status_code == 401
    assert admin.post("/api/auth/password", json={"current_password": PASSWORD, "new_password": "A-brand-new-password-1"}, headers=HEADERS).status_code == 429


def test_errors_are_json_and_do_not_leak_internals(client):
    for path in ["/api/nope", "/api/officers?page=abc", "/api/officers?page_size=x"]:
        response = client.get(path)
        assert response.is_json and "Traceback" not in response.get_data(as_text=True) and "invalid literal" not in response.get_data(as_text=True)
    assert client.delete("/api/health", headers=HEADERS).status_code == 405


def test_cross_origin_and_missing_header_requests_are_refused(admin):
    assert admin.post("/api/officers", json=RECORD).status_code == 403
    assert admin.post("/api/officers", json=RECORD, headers={**HEADERS, "Origin": "https://evil.example"}).status_code == 403
    assert "Access-Control-Allow-Origin" not in admin.get("/api/health", headers={"Origin": "https://evil.example"}).headers


def test_static_file_path_traversal_is_contained(client):
    for path in ["/../server/app.py", "/..%2fserver%2fapp.py", "/%2e%2e/server/config.py", "/server/app.py", "/.env"]:
        body = client.get(path).get_data(as_text=True)
        assert "create_app" not in body and "runtime_config" not in body, path


def test_session_count_is_capped(client):
    client.post("/api/auth/setup", json={"password": PASSWORD}, headers=HEADERS)
    for _ in range(30):
        assert client.post("/api/auth/login", json={"password": PASSWORD}, headers=HEADERS).status_code == 200
