import { chromium, expect } from "@playwright/test";
import fs from "node:fs/promises";

// Run against an isolated test server. NEVER point this at a real directory.
const base = process.env.TEST_URL || "http://localhost:3002";
const password = "Browser-test-password-482!";
const nextPassword = "New-browser-password-961!";
const artifacts = new URL("./artifacts/", import.meta.url);
await fs.mkdir(artifacts, { recursive: true });
const browser = await chromium.launch({
  headless: true,
  // Only the test harness relaxes Chromium's loopback-network check so it can
  // deliberately embed localhost under 127.0.0.1. Public HTTPS previews do not
  // need this flag; no browser-security setting is changed by the application.
  args: ["--no-sandbox", "--disable-features=LocalNetworkAccessChecks"],
});
const context = await browser.newContext({
  viewport: { width: 1440, height: 1080 },
  acceptDownloads: true,
});
const page = await context.newPage();
const errors = [];
const serverErrors = [];
page.on("pageerror", (error) => errors.push(error.message));
page.on("response", (response) => {
  if (response.status() >= 500)
    serverErrors.push(`${response.status()} ${response.url()}`);
});
const results = [];
async function test(name, work) {
  try {
    await work();
    results.push({ name, status: "PASS" });
    console.log(`PASS ${name}`);
  } catch (error) {
    results.push({ name, status: "FAIL", error: error.message });
    await page.screenshot({
      path: new URL("browser-failure.png", artifacts).pathname,
      fullPage: true,
      animations: "disabled",
    });
    throw error;
  }
}
async function search(value) {
  await page.getByRole("textbox", { name: "Search officers" }).fill(value);
}
async function download(menuItem, filename) {
  await page
    .getByRole("button", { name: "Export officers", exact: true })
    .click();
  const event = page.waitForEvent("download");
  await page.getByRole("button", { name: menuItem }).click();
  const item = await event;
  await item.saveAs(new URL(filename, artifacts).pathname);
  return item;
}

try {
  await test("Public directory loads with a real database and eight officers", async () => {
    await page.goto(base, { waitUntil: "networkidle" });
    await expect(page.locator("h1")).toContainText("Officer directory");
    await expect(page.locator("tr.officer-row")).toHaveCount(8);
    expect(
      (await (await page.request.get(`${base}/api/stats`)).json()).total,
    ).toBe(24);
    expect(
      (await (await page.request.get(`${base}/api/auth/status`)).json())
        .configured,
    ).toBe(false);
    expect(
      (
        await page.request.post(`${base}/api/officers`, {
          headers: { "X-Roster-Request": "1" },
          data: {},
        })
      ).status(),
    ).toBe(401);
  });
  await test("Search by name, badge, and no-match states", async () => {
    await search("Aiden Brooks");
    await expect(page.locator("tr.officer-row")).toHaveCount(1);
    await expect(page.locator(".officer-name")).toContainText("Aiden Brooks");
    await search("OF-1043");
    await expect(page.locator(".officer-name")).toContainText("Amelia Carter");
    await search("NobodyMatchesThis");
    await expect(page.locator(".empty-state h2")).toContainText("No one here");
    await page.getByRole("button", { name: "Clear search & filters" }).click();
    await expect(page.locator("tr.officer-row")).toHaveCount(8);
  });
  await test("Clickable column sorting in both directions", async () => {
    await page
      .getByRole("button", { name: "Sort by Officer", exact: true })
      .click();
    await expect(page.locator(".officer-name").first()).toContainText(
      "Zoe Williams",
    );
    await page
      .getByRole("button", { name: "Sort by Badge no.", exact: true })
      .click();
    await expect(page.locator(".badge-number").first()).toHaveText("OF-1042");
    await page
      .getByRole("button", { name: "Sort by Badge no.", exact: true })
      .click();
    await expect(page.locator(".badge-number").first()).toHaveText("OF-1065");
    await page
      .getByRole("button", { name: "Sort by Officer", exact: true })
      .click();
    await expect(page.locator(".officer-name").first()).toContainText(
      "Aiden Brooks",
    );
  });
  await test("Status tabs, rank filters, and column visibility", async () => {
    await page.getByRole("tab", { name: /On leave/ }).click();
    await expect(page.locator("tr.officer-row")).toHaveCount(2);
    await page.getByRole("tab", { name: /Off duty/ }).click();
    await expect(page.locator("tr.officer-row")).toHaveCount(6);
    await page.getByRole("tab", { name: /All officers/ }).click();
    await page
      .getByRole("button", { name: "Filter officers", exact: true })
      .click();
    await page
      .getByRole("combobox", { name: "Filter by rank" })
      .selectOption("Sergeant");
    await page.getByRole("button", { name: "Done", exact: true }).click();
    await expect(page.locator("tr.officer-row")).toHaveCount(4);
    expect(await page.locator(".rank-text").allTextContents()).toEqual([
      "Sergeant",
      "Sergeant",
      "Sergeant",
      "Sergeant",
    ]);
    await page.getByRole("button", { name: "Clear all", exact: true }).click();
    await page
      .getByRole("button", { name: "Visible columns", exact: true })
      .click();
    await page
      .getByRole("dialog", { name: "Visible columns" })
      .getByLabel("Assignment", { exact: true })
      .uncheck();
    await expect(
      page.getByRole("button", { name: "Sort by Assignment", exact: true }),
    ).toHaveCount(0);
    await page
      .getByRole("dialog", { name: "Visible columns" })
      .getByLabel("Assignment", { exact: true })
      .check();
    await page.keyboard.press("Escape");
  });
  await test("Pagination and page size", async () => {
    const before = await page.locator(".officer-name strong").allTextContents();
    await page.getByRole("button", { name: "Page 2", exact: true }).click();
    await expect(
      page.getByRole("button", { name: "Page 2", exact: true }),
    ).toHaveAttribute("aria-current", "page");
    await expect(page.locator(".officer-name strong").first()).not.toHaveText(
      before[0],
    );
    await page
      .getByRole("combobox", { name: "Officers per page" })
      .selectOption("24");
    await expect(page.locator("tr.officer-row")).toHaveCount(24);
    await page
      .getByRole("combobox", { name: "Officers per page" })
      .selectOption("8");
    await expect(page.locator("tr.officer-row")).toHaveCount(8);
  });
  await test("Edits are gated and first-use password setup opens the management panel", async () => {
    await page
      .getByRole("button", { name: "Add officer", exact: true })
      .click();
    await expect(
      page.getByRole("dialog", { name: "Set up admin access", exact: true }),
    ).toBeVisible();
    await expect(
      page.getByRole("dialog", { name: "Add an officer", exact: true }),
    ).toHaveCount(0);
    await page.keyboard.press("Escape");
    await page
      .getByRole("button", { name: "Manage officers", exact: true })
      .click();
    const auth = page.getByRole("dialog", {
      name: "Set up admin access",
      exact: true,
    });
    await auth.getByLabel("Admin password", { exact: true }).fill(password);
    await auth.getByLabel("Confirm password", { exact: true }).fill(password);
    await auth.getByRole("button", { name: "Set password & continue" }).click();
    await expect(page.locator("h1")).toContainText("Manage officers");
    await expect(page.locator(".view-access")).toContainText("Edits unlocked");
    await expect(page.getByRole("dialog")).toHaveCount(0);
  });
  await test("Add an officer with contact details, assignment, status, and notes", async () => {
    await page
      .getByRole("button", { name: "Add officer", exact: true })
      .click();
    const form = page.getByRole("dialog", {
      name: "Add an officer",
      exact: true,
    });
    await form.getByLabel(/^Full name/).fill("Test Officer UI");
    await form.getByLabel(/^Badge number/).fill("UI-9001");
    await form.getByLabel(/^Rank/).selectOption("Lieutenant");
    await form.getByLabel(/^Assignment/).fill("Browser Test Unit");
    await form.getByLabel(/^Status/).selectOption("Off duty");
    await form
      .getByLabel("Email address", { exact: true })
      .fill("test-ui@example.com");
    await form.getByLabel("Phone number", { exact: true }).fill("+1 555 0123");
    await form.getByLabel("Joined date", { exact: true }).fill("2024-01-15");
    await form
      .getByLabel("Notes", { exact: true })
      .fill("Created by a browser integration test.");
    await form
      .getByRole("button", { name: "Add officer", exact: true })
      .click();
    await expect(form).toHaveCount(0);
    await search("UI-9001");
    await expect(page.locator("tr.officer-row")).toHaveCount(1);
    await expect(page.locator(".officer-name")).toContainText(
      "Test Officer UI",
    );
    await expect(page.locator(".status-pill")).toHaveText("Off duty");
    expect(
      (await (await page.request.get(`${base}/api/stats`)).json()).total,
    ).toBe(25);
  });
  await test("Duplicate badge validation is shown in the add form", async () => {
    await page
      .getByRole("button", { name: "Add officer", exact: true })
      .click();
    const form = page.getByRole("dialog", {
      name: "Add an officer",
      exact: true,
    });
    await form.getByLabel(/^Full name/).fill("Duplicate Test");
    await form.getByLabel(/^Badge number/).fill("UI-9001");
    await form.getByLabel(/^Assignment/).fill("Browser Test Unit");
    await form
      .getByRole("button", { name: "Add officer", exact: true })
      .click();
    await expect(form.getByRole("alert")).toContainText("already in use");
    await form.getByRole("button", { name: "Cancel", exact: true }).click();
  });
  await test("Refresh preserves database records and the admin session", async () => {
    await page.reload({ waitUntil: "networkidle" });
    expect(
      (await (await page.request.get(`${base}/api/auth/status`)).json())
        .authenticated,
    ).toBe(true);
    await search("UI-9001");
    await expect(page.locator("tr.officer-row")).toHaveCount(1);
    await page.locator(".officer-name").click();
    const profile = page.getByRole("dialog", {
      name: "Test Officer UI profile",
      exact: true,
    });
    await expect(profile).toContainText(
      "Created by a browser integration test.",
    );
    await expect(profile).toContainText("test-ui@example.com");
    await expect(profile).toContainText("Browser Test Unit");
  });
  await test("Edit an existing officer and update the live directory", async () => {
    await page
      .getByRole("button", { name: "Edit details", exact: true })
      .click();
    const form = page.getByRole("dialog", {
      name: "Edit officer",
      exact: true,
    });
    await form.getByLabel(/^Full name/).fill("Taylor Morgan UI");
    await form.getByLabel(/^Status/).selectOption("On leave");
    await form
      .getByLabel("Notes", { exact: true })
      .fill("Updated and persisted by browser test.");
    await form
      .getByRole("button", { name: "Save changes", exact: true })
      .click();
    await expect(form).toHaveCount(0);
    await expect(page.locator(".officer-name")).toContainText(
      "Taylor Morgan UI",
    );
    await expect(page.locator(".status-pill")).toHaveText("On leave");
  });
  await test("Download a filtered CSV and a genuine Excel workbook", async () => {
    const csv = await download("Export as CSV", "officers-filtered.csv");
    expect(csv.suggestedFilename()).toMatch(/\.csv$/);
    const content = await fs.readFile(
      new URL("officers-filtered.csv", artifacts),
      "utf8",
    );
    expect(content).toContain("Taylor Morgan UI");
    expect(content).not.toContain("Aiden Brooks");
    expect(content.trim().split("\n")).toHaveLength(2);
    const excel = await download("Export as Excel", "officers-filtered.xlsx");
    expect(excel.suggestedFilename()).toMatch(/\.xlsx$/);
    const bytes = await fs.readFile(
      new URL("officers-filtered.xlsx", artifacts),
    );
    expect(bytes.subarray(0, 2).toString()).toBe("PK");
  });
  await test("Export center, overview, and activity pages all work", async () => {
    await page.getByRole("button", { name: "Exports", exact: true }).click();
    await expect(page.locator("h1")).toContainText("Exports");
    await page
      .getByRole("combobox", { name: "Export scope" })
      .selectOption("filtered");
    await expect(page.locator(".export-file-details").first()).toContainText(
      "1 officer records",
    );
    await page.getByRole("button", { name: "Overview", exact: true }).click();
    await expect(page.locator("h1")).toContainText("Overview");
    await expect(page.locator(".donut")).toBeVisible();
    await expect(page.locator(".unit-row")).toHaveCount(7);
    await page
      .getByRole("button", { name: "Activity log", exact: true })
      .click();
    await page
      .getByRole("combobox", { name: "Filter activity" })
      .selectOption("updated");
    await expect(page.locator(".activity-list")).toContainText(
      "Taylor Morgan UI's details were updated",
    );
    await page
      .getByRole("button", { name: "Back to directory", exact: true })
      .click();
  });
  await test("Sign-out re-locks edits; an incorrect password cannot unlock them", async () => {
    await page.getByRole("button", { name: "Sign out", exact: true }).click();
    await expect(page.locator(".view-access")).toContainText("Public view");
    await page
      .getByRole("button", {
        name: "Actions for Taylor Morgan UI",
        exact: true,
      })
      .click();
    await page
      .getByRole("button", { name: "Remove officer", exact: true })
      .click();
    const auth = page.getByRole("dialog", {
      name: "Admin access",
      exact: true,
    });
    await expect(auth).toBeVisible();
    await auth
      .getByLabel("Admin password", { exact: true })
      .fill("Incorrect-password");
    await auth.getByRole("button", { name: "Unlock management panel" }).click();
    await expect(auth.getByRole("alert")).toContainText("Incorrect password");
    await expect(
      page.getByRole("dialog", { name: "Confirm removal", exact: true }),
    ).toHaveCount(0);
    await auth.getByLabel("Admin password", { exact: true }).fill(password);
    await auth.getByRole("button", { name: "Unlock management panel" }).click();
    await expect(
      page.getByRole("dialog", { name: "Confirm removal", exact: true }),
    ).toBeVisible();
  });
  await test("Removal requires confirmation, can be cancelled, and persists", async () => {
    const confirm = page.getByRole("dialog", {
      name: "Confirm removal",
      exact: true,
    });
    await confirm
      .getByRole("button", { name: "Keep officer", exact: true })
      .click();
    await expect(page.locator("tr.officer-row")).toHaveCount(1);
    await page
      .getByRole("button", {
        name: "Actions for Taylor Morgan UI",
        exact: true,
      })
      .click();
    await page
      .getByRole("button", { name: "Remove officer", exact: true })
      .click();
    await page
      .getByRole("dialog", { name: "Confirm removal", exact: true })
      .getByRole("button", { name: "Remove officer", exact: true })
      .click();
    await expect(page.locator("tr.officer-row")).toHaveCount(0);
    await page.reload({ waitUntil: "networkidle" });
    await search("UI-9001");
    await expect(page.locator(".empty-state")).toBeVisible();
    expect(
      (await (await page.request.get(`${base}/api/stats`)).json()).total,
    ).toBe(24);
    await page.getByRole("button", { name: "Clear search & filters" }).click();
  });
  await test("Bulk selection and protected removal", async () => {
    await page
      .getByRole("checkbox", { name: "Select Aiden Brooks", exact: true })
      .check();
    await page
      .getByRole("checkbox", { name: "Select Amelia Carter", exact: true })
      .check();
    await expect(page.locator(".selection-bar")).toContainText("2");
    await page
      .getByRole("button", { name: "Remove selected", exact: true })
      .click();
    await page
      .getByRole("dialog", { name: "Confirm removal", exact: true })
      .getByRole("button", { name: "Remove officers", exact: true })
      .click();
    await expect(page.locator(".selection-bar")).toHaveCount(0);
    await expect(page.locator(".officer-name").first()).toContainText(
      "Ava Bennett",
    );
    expect(
      (await (await page.request.get(`${base}/api/stats`)).json()).total,
    ).toBe(22);
  });
  await test("The password can be changed and the new password works", async () => {
    await page
      .getByRole("button", { name: "Admin account", exact: true })
      .click();
    await page
      .getByRole("button", { name: "Change password", exact: true })
      .click();
    const form = page.getByRole("dialog", {
      name: "Change admin password",
      exact: true,
    });
    await form.getByLabel("Current password", { exact: true }).fill(password);
    await form.getByLabel("New password", { exact: true }).fill(nextPassword);
    await form
      .getByLabel("Confirm password", { exact: true })
      .fill(nextPassword);
    await form
      .getByRole("button", { name: "Update password", exact: true })
      .click();
    await expect(form).toHaveCount(0);
    await page.getByRole("button", { name: "Sign out", exact: true }).click();
    await page
      .getByRole("button", { name: "Admin access", exact: true })
      .click();
    const auth = page.getByRole("dialog", {
      name: "Admin access",
      exact: true,
    });
    await auth.getByLabel("Admin password", { exact: true }).fill(nextPassword);
    await auth.getByRole("button", { name: "Unlock management panel" }).click();
    await expect(page.locator("h1")).toContainText("Manage officers");
    await page.getByRole("button", { name: "Sign out", exact: true }).click();
  });
  await test("Keyboard search, help, and responsive mobile navigation", async () => {
    await page.keyboard.press("Control+k");
    await expect(
      page.getByRole("textbox", { name: "Search officers" }),
    ).toBeFocused();
    await page
      .getByRole("button", { name: "A little help", exact: true })
      .click();
    await expect(
      page.getByRole("dialog", { name: "A little help", exact: true }),
    ).toBeVisible();
    await page.keyboard.press("Escape");
    await page.setViewportSize({ width: 390, height: 844 });
    await expect(
      page.getByRole("button", { name: "Open navigation", exact: true }),
    ).toBeVisible();
    await page
      .getByRole("button", { name: "Open navigation", exact: true })
      .click();
    await expect(page.locator(".sidebar")).toHaveClass(/sidebar-open/);
    await page.getByRole("button", { name: "Overview", exact: true }).click();
    await expect(page.locator("h1")).toContainText("Overview");
    await expect(page.locator(".sidebar")).not.toHaveClass(/sidebar-open/);
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
    await page
      .getByRole("button", { name: "Open navigation", exact: true })
      .click();
    await page
      .getByRole("button", { name: "Officer directory", exact: true })
      .click();
    await expect(page.locator("h1")).toContainText("Officer directory");
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
  });
  await test("Password access works inside a cross-site embedded preview", async () => {
    const embeddedContext = await browser.newContext({
      viewport: { width: 1440, height: 1080 },
    });
    const embeddedPage = await embeddedContext.newPage();
    embeddedPage.on("pageerror", (error) => errors.push(error.message));
    const outer = `http://127.0.0.1:${new URL(base).port}/embedded-frame-test`;
    await embeddedPage.route(outer, (route) =>
      route.fulfill({
        status: 200,
        contentType: "text/html",
        body: `<!doctype html><html><body style="margin:0"><iframe id="workspace" src="${base}" style="width:100vw;height:100vh;border:0" sandbox="allow-scripts allow-same-origin allow-forms allow-downloads"></iframe></body></html>`,
      }),
    );
    await embeddedPage.goto(outer);
    const workspace = embeddedPage.frameLocator("#workspace");
    await workspace
      .getByRole("button", { name: "Admin access", exact: true })
      .click();
    const auth = workspace.getByRole("dialog", {
      name: "Admin access",
      exact: true,
    });
    await auth.getByLabel("Admin password", { exact: true }).fill(nextPassword);
    await auth.getByRole("button", { name: "Unlock management panel" }).click();
    await expect(workspace.locator("h1")).toContainText("Manage officers");
    const frame = embeddedPage.frames().find((f) => f.url().startsWith(base));
    const result = await frame.evaluate(async () => {
      const auth = await (await fetch("/api/auth/status")).json();
      const options = (method, data) => ({
        method,
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
          "X-Roster-Request": "1",
        },
        ...(data ? { body: JSON.stringify(data) } : {}),
      });
      const create = await fetch(
        "/api/officers",
        options("POST", {
          name: "Embedded Officer Check",
          badge_id: "BROWSER-FRAME",
          rank: "Officer",
          assignment: "Embedded Test Unit",
          status: "On duty",
        }),
      );
      const officer = await create.json();
      if (!create.ok)
        return { authenticated: auth.authenticated, created: create.status };
      const edit = await fetch(
        `/api/officers/${officer.id}`,
        options("PUT", { ...officer, status: "Off duty" }),
      );
      const remove = await fetch(
        `/api/officers/${officer.id}`,
        options("DELETE"),
      );
      return {
        authenticated: auth.authenticated,
        created: create.status,
        edited: edit.status,
        removed: remove.status,
      };
    });
    expect(result).toEqual({
      authenticated: true,
      created: 201,
      edited: 200,
      removed: 200,
    });
    await embeddedContext.close();
  });
  await test("No JavaScript errors or server errors", async () => {
    expect(errors).toEqual([]);
    expect(serverErrors).toEqual([]);
  });
} catch (error) {
  console.error(error);
  process.exitCode = 1;
} finally {
  await fs.writeFile(
    new URL("browser-results.json", artifacts),
    JSON.stringify({ results, errors, serverErrors }, null, 2),
  );
  console.log(
    `\n${results.filter((r) => r.status === "PASS").length}/${results.length} browser checks passed.`,
  );
  await browser.close();
}
