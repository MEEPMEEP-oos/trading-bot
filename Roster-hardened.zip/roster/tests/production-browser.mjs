import { chromium, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import fs from 'node:fs/promises';

// Destructive tests: this must be an isolated, empty production-mode workspace.
const base = process.env.PRODUCTION_TEST_URL || 'http://127.0.0.1:3080';
const password = process.env.PRODUCTION_TEST_PASSWORD;
if (!password) throw new Error('Set PRODUCTION_TEST_PASSWORD for the isolated production test server.');
const browser = await chromium.launch({ args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 1440, height: 1080 }, reducedMotion: 'reduce', acceptDownloads: true });
const page = await context.newPage();
const errors = [];
const blocked = [];
page.on('pageerror', e => errors.push(e.message));
page.on('console', msg => { if (msg.type() === 'error' && /Content Security Policy|Refused to/.test(msg.text())) blocked.push(msg.text()); });
await fs.mkdir('tests/artifacts', { recursive: true });
async function settled() {
  await page.waitForFunction(() => [...document.querySelectorAll('.directory-section,.dialog,.dialog-backdrop,.stat-card,.toast')].every(el => getComputedStyle(el).opacity === '1'));
}
try {
  await page.goto(base, { waitUntil: 'networkidle' });
  // Private by default: no directory data is rendered or fetched before sign-in.
  const auth = page.getByRole('dialog', { name: 'Admin access', exact: true });
  await expect(auth).toContainText('Welcome back.');
  await expect(page.locator('.officer-name')).toHaveCount(0);
  await expect(auth.getByLabel('Confirm password', { exact: true })).toHaveCount(0);
  const anonymous = await page.evaluate(() => fetch('/api/officers').then(r => r.status));
  expect(anonymous).toBe(401);
  await auth.getByLabel('Admin password', { exact: true }).fill(password);
  await auth.getByRole('button', { name: 'Unlock management panel' }).click();
  await expect(page.locator('.empty-state')).toContainText('Your team starts here.');
  await settled();
  const audit = await new AxeBuilder({ page }).analyze();
  expect(audit.violations).toEqual([]);
  console.log('PASS sign-in gate, empty production directory and automatic accessibility audit.');
  await page.getByRole('button', { name: 'Manage officers', exact: true }).click();
  await expect(page.locator('h1')).toContainText('Manage officers');
  await page.getByRole('button', { name: 'Add officer', exact: true }).click();
  const form = page.getByRole('dialog', { name: 'Add an officer', exact: true });
  await form.getByLabel(/^Full name/).fill('Production Browser Check');
  await form.getByLabel(/^Badge number/).fill('PROD-BROWSER');
  await form.getByLabel(/^Assignment/).fill('Verification Unit');
  await form.getByRole('button', { name: 'Add officer', exact: true }).click();
  await expect(page.locator('tr.officer-row')).toHaveCount(1);
  await page.reload({ waitUntil: 'networkidle' });
  await expect(page.locator('.officer-name')).toContainText('Production Browser Check');
  console.log('PASS environment-initialized login, protected add, and refresh persistence.');
  await page.getByRole('button', { name: 'Export officers', exact: true }).click();
  const downloadEvent = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export as Excel' }).click();
  const download = await downloadEvent;
  await download.saveAs('tests/artifacts/production-export.xlsx');
  expect(download.suggestedFilename()).toMatch(/\.xlsx$/);
  await page.getByRole('button', { name: 'Actions for Production Browser Check', exact: true }).click();
  await page.getByRole('button', { name: 'Remove officer', exact: true }).click();
  await page.getByRole('dialog', { name: 'Confirm removal', exact: true }).getByRole('button', { name: 'Remove officer', exact: true }).click();
  await expect(page.locator('.empty-state')).toBeVisible();
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await settled();
  expect(errors).toEqual([]);
  expect(blocked).toEqual([]);
  console.log('PASS production Excel download, deletion, mobile layout, and no CSP/browser errors.');
  await fs.writeFile('tests/artifacts/production-browser-results.json', JSON.stringify({ passed: true, errors, blocked, accessibilityViolations: audit.violations }, null, 2));
} catch (error) {
  await page.screenshot({ path: 'tests/artifacts/production-browser-failure.png', fullPage: true, animations: 'disabled' });
  throw error;
} finally {
  await browser.close();
}
