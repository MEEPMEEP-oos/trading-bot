# Deployment schema provenance

`render.schema.json` is a local snapshot of Render's official JSON Schema, retrieved on 2026-10-01 from:

https://render.com/schema/render.yaml.json

It is used for offline validation of `render.yaml` in `test_deployment.py`. No live officer data or secrets are sent to Render by the tests. The hosting dashboard performs its own current validation when creating a Blueprint.
