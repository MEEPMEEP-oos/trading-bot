# Deploy Roster

**Recommended: Render + the included Dockerfile and persistent disk.** You can also use Docker Compose on a computer or VPS. The complete React/Flask/SQLite application must run together; uploading only `web/` to a static host will not provide a working database or admin panel.

This project is deployment-ready, not already published to a hosting account. The live workspace preview is temporary and is not permanent hosting.

## 1. Render — simplest public deployment

1. Extract `Roster-deployment-ready.zip` and create a GitHub repository containing the **contents of the `roster` folder**. `Dockerfile`, `render.yaml`, and `package.json` must be at the repository root. Do not upload the ZIP itself or a private database.
2. Enable GitHub Actions. The included workflow runs application tests and builds/smoke-tests the Docker image. Use the `main` branch and wait for both jobs to pass.
3. Sign in to [Render](https://dashboard.render.com/) and select **New → Blueprint**. Connect that GitHub repository. Render reads `render.yaml`.
4. Review the resources: one Docker web service and a **1 GB persistent disk** at `/var/data`. The blueprint selects a paid `0.5c-512mb` service. **A paid service/disk is necessary for persistent SQLite on Render; review the current price before confirming.** Do not replace it with a free diskless service.
5. When prompted for **`ROSTER_ADMIN_PASSWORD`**, enter your own unique password. Use 16+ random characters if possible; the application requires 12–128 and rejects common or repetitive values. This field is a private hosting setting, not source code. There is no preset password.
6. Apply/create the Blueprint. The Docker build compiles React and installs the backend. The database initializes only at runtime, on the persistent disk.
7. When the service is healthy, open the HTTPS address shown by Render. Click **Admin access**, enter the password from step 5, and add your officers. A new production directory starts empty—no fictional officers are published by default.

`/api/health` is the readiness check. The blueprint enables automatic deployment after GitHub checks pass. To add a domain, use Render's custom-domain settings and keep HTTPS enabled.

### What survives an update?

Officers, notes, activity history, the saved admin password hash, and sessions are stored in `/var/data/roster.sqlite3`. That directory is the attached disk, not the ephemeral image filesystem. Code changes, image rebuilds, and normal service restarts do not replace it.

- Keep **one instance**. This is a single-instance SQLite application, not a horizontally scaled service.
- A disk-backed service can have a brief interruption during redeployment. Do not expect zero-downtime deployments.
- Never delete the disk to upgrade the website.
- Backups are still necessary; a persistent disk is not itself a backup.
- Changing `ROSTER_ADMIN_PASSWORD` later does **not** change an existing password. Use the UI's **Change password**, or the private reset command below. This avoids undoing a UI password change on every redeploy.

Official references: [Blueprint configuration](https://render.com/docs/blueprint-spec), [persistent disks and their limitations](https://render.com/docs/disks).

## 2. Docker Compose — local machine or VPS

Install Docker Engine/Desktop with Compose v2. From the project folder:

```bash
cp .env.example .env
# Open .env in your editor and set ROSTER_ADMIN_PASSWORD before continuing.
docker compose up --build -d
docker compose ps
```

Open **http://localhost:3000**. The default binding is loopback-only. The production-mode database is in the named volume `roster_officer-data`, outside the image. Local Docker uses `COOKIE_SECURE=false` because localhost is served over HTTP.

To update:

```bash
git pull  # If this installation uses a Git repository.
docker compose up --build -d
```

**Do not run `docker compose down -v`.** The `-v` flag deletes the database volume. `docker compose down` without that flag retains it. Do not use volume-pruning commands on a volume you need.

### Public VPS: HTTPS is required

Put a trusted HTTPS reverse proxy in front of the loopback listener. With Caddy installed directly on the same VPS, for example:

```caddyfile
roster.your-domain.example {
    reverse_proxy 127.0.0.1:3000
}
```

Replace the example hostname with your domain and point its DNS to the VPS. Allow public ports 80/443 for the proxy. Leave the backend bound to `127.0.0.1`; do not expose port 3000 to the Internet.

In `.env`, set `COOKIE_SECURE=true`, keep `COOKIE_SAMESITE=Lax`, and keep `COOKIE_PARTITIONED=false`. Then recreate the app with `docker compose up -d`. If you need accurate forwarded client IP/scheme information, set `TRUSTED_PROXY` to the proxy's address as seen by the container. `*` is acceptable only when **all traffic is forced through a controlled proxy** and the backend cannot be reached directly. Render's provided blueprint uses its managed ingress.

If the reverse proxy is another container, it must connect over a private Docker network rather than using its own localhost. Adjust Compose networking accordingly; the Caddy example above is specifically for a proxy installed on the host.

The image has a health check and a non-root HTTP process (UID/GID 10001). Its initial launcher only prepares the dedicated volume permissions before dropping privileges. Compose additionally makes the image filesystem read-only, with a temporary directory for workbook generation.

## 3. Backups, moving existing data, and forgotten passwords

Maintenance commands are available only through your server/container shell. There is no public reset, backup, or restore API. A database backup contains officer information and password hashes: keep it private and off GitHub. CSV/Excel exports are useful reports but do not preserve the entire database or admin configuration.

### Consistent backup while running

Docker Compose:

```bash
docker compose exec roster python -m server.manage backup /data/backups/roster-2026-10-01.sqlite3
# Save it off the hosting machine. Replace the filename with your chosen date.
docker compose cp roster:/data/backups/roster-2026-10-01.sqlite3 ./roster-private-backup.sqlite3
```

Render Shell:

```bash
python -m server.manage backup /var/data/backups/roster-2026-10-01.sqlite3
```

Download/transfer the backup using your provider's private SSH/SCP access. Store copies outside the mounted disk and test a restore periodically. The command refuses to overwrite an existing backup filename. It uses SQLite's backup API, which safely captures committed WAL transactions; do not copy just the live `.sqlite3` file while the server is writing it.

### Migrate a local workspace

On the old/local installation:

```bash
.venv/bin/python -m server.manage backup /private/location/roster-transfer.sqlite3
```

Securely upload that snapshot to the destination. Do not commit it. On Render, use private SSH/SCP or your provider's secure transfer mechanism to place it on the runtime disk, for example `/var/data/transfer.sqlite3`. In Render Shell:

```bash
python -m server.manage restore /var/data/transfer.sqlite3 --database /var/data/imported.sqlite3
```

Restore creates a **new filename** and never overwrites the running database. Set `ROSTER_DB=/var/data/imported.sqlite3` in your hosting settings **and update `render.yaml` to the same value** so later Blueprint synchronization retains it. Redeploy and verify the officers. Existing admin credentials from the old database are preserved; old sessions are revoked. If the old workspace had no admin password, the hosting bootstrap password initializes it on startup. Keep the previous file until you have verified the migration.

For a new Docker volume **before its first web startup**, place the snapshot at `import/transfer.sqlite3` in your project folder and run:

```bash
docker compose build
docker compose run --rm --no-deps --entrypoint python \
  -v "$PWD/import:/import:ro" roster \
  -m server.manage restore /import/transfer.sqlite3
docker compose up -d
```

This creates `/data/roster.sqlite3` only if it does not already exist. On an existing installation, restore to an unused filename instead, then change the Compose `ROSTER_DB` setting to that path under `/data` and recreate the service. Never swap/delete SQLite files while they are in use.

### Reset a forgotten admin password

Docker Compose:

```bash
docker compose exec -it roster python -m server.manage set-password
```

Render Shell:

```bash
python -m server.manage set-password
```

Local:

```bash
.venv/bin/python -m server.manage set-password
```

The command prompts privately and requires confirmation. It changes only the admin password hash, revokes active sessions, and records an audit entry; it does not delete officers. The password is not passed on the command line. Be sure `ROSTER_DB` (or `--database`) points to the correct workspace.

## 4. Environment reference

| Setting | Deployment value / behavior |
|---|---|
| `ROSTER_ENV` | `production` for hosting; local default is `development` |
| `PORT` | Internal HTTP port; Render blueprint uses 10000, Docker uses 8000 |
| `ROSTER_DB` | Absolute SQLite path **inside your persistent mount** |
| `ROSTER_ADMIN_PASSWORD` | Required on the first production start; ignored when a password already exists |
| `ROSTER_PUBLIC_VIEW` | Defaults **false** in production: every directory, activity and export endpoint needs sign-in. `true` makes the directory publicly readable |
| `ROSTER_ALLOWED_HOSTS` | Optional comma-separated list of your own domain(s); other `Host` headers are rejected |
| `ROSTER_SEED_DEMO` | Defaults false in production, true in local development; applies only to a new database |
| `COOKIE_SECURE` | Defaults true in production; false only for a local HTTP test |
| `COOKIE_SAMESITE` | `Lax` for the standalone website |
| `COOKIE_PARTITIONED` | False for a standalone site |
| `FRAME_ANCESTORS` | Defaults `'self'` in production; controls trusted iframe origins |
| `TRUSTED_PROXY` | Leave blank unless behind a controlled ingress/proxy |

For cross-site HTTPS embedding, use `COOKIE_SECURE=true`, `COOKIE_SAMESITE=None`, `COOKIE_PARTITIONED=true`, and a `FRAME_ANCESTORS` value containing the exact trusted embedding origin. Open directly in a new tab if the browser blocks embedded storage. Do not use `FRAME_ANCESTORS=*` for a normal deployment.

Environment values are validated. Production fails before listening if initial admin credentials or the built frontend are missing. Production also adds a Content Security Policy and security headers. Keep secrets out of `.env.example`, Dockerfile, manifests, and the repository; `.env` and databases are ignored by Git and the Docker build context.

## 5. Verify a real deployment

1. Confirm the HTTPS homepage loads and `/api/health` reports a connected database.
2. Check that the site shows a sign-in screen, that `/api/officers` returns 401 when signed out, and that everything works after you sign in with your password.
3. Add a harmless test officer, edit it, and download CSV and Excel.
4. Restart/redeploy the service; confirm that officer remains and the current admin password still works.
5. Remove the test officer. Create an off-host backup and test restoration to a separate file.

**Privacy:** in production the directory, contacts, notes, activity, and exports require the admin password by default (`ROSTER_PUBLIC_VIEW=false`). If you set `ROSTER_PUBLIC_VIEW=true`, all of it becomes readable by anyone and the password protects only changes. Use approved work information only. SQLite files and backups are not app-encrypted. There is one shared admin role, not per-user identities or multi-factor authentication.

**Hosting scope:** this durable-disk, long-running server architecture is not a static Netlify/Vercel upload or a scale-to-zero serverless function. A Docker-capable provider is fine if it supports a persistent writable filesystem and a single running instance.
