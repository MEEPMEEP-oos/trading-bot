import React, { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import {
  Activity,
  ArrowDown,
  ArrowDownLeft,
  ArrowDownToLine,
  ArrowRight,
  ArrowUp,
  ArrowUpDown,
  BadgeCheck,
  Building2,
  Check,
  CheckCheck,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CircleHelp,
  Columns3,
  Command,
  Database,
  Download,
  Eye,
  EyeOff,
  FileSpreadsheet,
  FileText,
  Fingerprint,
  Grid2X2,
  LayoutDashboard,
  ListFilter,
  Loader2,
  LockKeyhole,
  LogOut,
  Mail,
  Menu,
  MoreHorizontal,
  Pencil,
  Phone,
  Plus,
  Search,
  Shield,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Trash2,
  UnlockKeyhole,
  UserRound,
  UserRoundCheck,
  UserRoundPlus,
  UsersRound,
  X,
} from "lucide-react";

const RANKS = [
  "Officer",
  "Senior Officer",
  "Corporal",
  "Sergeant",
  "Lieutenant",
  "Captain",
];
const STATUSES = ["On duty", "Off duty", "On leave"];
const VIEW_LABELS = {
  directory: "Officer directory",
  overview: "Overview",
  activity: "Activity log",
  exports: "Exports",
  manage: "Manage officers",
};
const COLUMNS = [
  { key: "name", label: "Officer" },
  { key: "badge_id", label: "Badge no." },
  { key: "rank", label: "Rank" },
  { key: "assignment", label: "Assignment" },
  { key: "status", label: "Status" },
];
const EMPTY_OFFICER = {
  name: "",
  badge_id: "",
  rank: "Officer",
  assignment: "",
  status: "On duty",
  email: "",
  phone: "",
  joined_date: "",
  notes: "",
};
const cx = (...parts) => parts.filter(Boolean).join(" ");

async function api(path, options = {}) {
  const response = await fetch(`/api${path}`, {
    credentials: "same-origin",
    ...options,
    headers: {
      "Content-Type": "application/json",
      "X-Roster-Request": "1",
      ...options.headers,
    },
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
  });
  const payload = await response.json();
  if (!response.ok) {
    const error = new Error(
      payload.error || "Something went wrong. Please try again.",
    );
    error.status = response.status;
    throw error;
  }
  return payload;
}

function useDebounced(value, delay = 200) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}

function initials(name) {
  return name
    .split(" ")
    .filter(Boolean)
    .map((n) => n[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}
function Avatar({ name, large = false }) {
  const color = [...name].reduce((sum, c) => sum + c.charCodeAt(0), 0) % 7;
  return (
    <span
      aria-hidden="true"
      className={cx("avatar", `avatar-${color}`, large && "avatar-large")}
    >
      {initials(name)}
    </span>
  );
}
function StatusPill({ status }) {
  return (
    <span
      className={cx(
        "status-pill",
        status === "On duty"
          ? "on-duty"
          : status === "Off duty"
            ? "off-duty"
            : "on-leave",
      )}
    >
      <i />
      {status}
    </span>
  );
}
function Button({
  children,
  icon: Icon,
  variant = "secondary",
  className = "",
  ...props
}) {
  return (
    <motion.button
      whileTap={{ scale: 0.975 }}
      className={cx("button", `button-${variant}`, className)}
      {...props}
    >
      {Icon && <Icon size={16} strokeWidth={1.8} />}
      {children}
    </motion.button>
  );
}
function Logo({ compact = false }) {
  return (
    <div className="brand">
      <div className="brand-mark">
        <span />
        <span />
        <span />
      </div>
      {!compact && (
        <span>
          roster<span className="brand-period">.</span>
        </span>
      )}
    </div>
  );
}
function relativeTime(stamp) {
  const minutes = Math.max(
    0,
    Math.floor((Date.now() - new Date(stamp).getTime()) / 60000),
  );
  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;
  if (minutes < 1440) return `${Math.floor(minutes / 60)}h ago`;
  if (minutes < 10080) return `${Math.floor(minutes / 1440)}d ago`;
  return new Date(stamp).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
  });
}
function humanDate(stamp) {
  return stamp
    ? new Date(
        stamp.length === 10 ? `${stamp}T12:00:00` : stamp,
      ).toLocaleDateString(undefined, {
        month: "long",
        day: "numeric",
        year: "numeric",
      })
    : "Not provided";
}

function Dropdown({
  trigger,
  label,
  children,
  className = "",
  disabled = false,
  align = "right",
}) {
  const [open, setOpen] = useState(false);
  const [position, setPosition] = useState({});
  const buttonRef = useRef(null);
  const menuRef = useRef(null);
  const toggle = () => {
    if (!open) {
      const r = buttonRef.current.getBoundingClientRect();
      const roomBelow = window.innerHeight - r.bottom;
      setPosition({
        ...(align === "left"
          ? { left: Math.max(12, r.left) }
          : { right: Math.max(12, window.innerWidth - r.right) }),
        ...(roomBelow < 255 && r.top > 280
          ? { bottom: window.innerHeight - r.top + 7 }
          : { top: r.bottom + 7 }),
      });
    }
    setOpen(!open);
  };
  useEffect(() => {
    if (!open) return;
    function outside(e) {
      if (
        !buttonRef.current?.contains(e.target) &&
        !menuRef.current?.contains(e.target)
      )
        setOpen(false);
    }
    function key(e) {
      if (e.key === "Escape") {
        setOpen(false);
        buttonRef.current?.focus();
      }
    }
    const close = () => setOpen(false);
    document.addEventListener("pointerdown", outside);
    document.addEventListener("keydown", key);
    window.addEventListener("resize", close);
    return () => {
      document.removeEventListener("pointerdown", outside);
      document.removeEventListener("keydown", key);
      window.removeEventListener("resize", close);
    };
  }, [open]);
  return (
    <>
      <button
        ref={buttonRef}
        type="button"
        className={cx("dropdown-trigger", className, open && "is-open")}
        onClick={toggle}
        aria-label={label}
        aria-expanded={open}
        aria-haspopup="dialog"
        disabled={disabled}
      >
        {trigger}
      </button>
      {createPortal(
        <AnimatePresence>
          {open && (
            <motion.div
              ref={menuRef}
              className="dropdown-menu"
              style={position}
              initial={{ opacity: 0, y: -5, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -4, scale: 0.98 }}
              transition={{ duration: 0.16 }}
              role="dialog"
              aria-label={label}
            >
              {typeof children === "function"
                ? children(() => setOpen(false))
                : children}
            </motion.div>
          )}
        </AnimatePresence>,
        document.body,
      )}
    </>
  );
}

function Dialog({ label, children, onClose, drawer = false, className = "" }) {
  const ref = useRef(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const previouslyFocused = document.activeElement;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const frame = requestAnimationFrame(() =>
      (
        ref.current?.querySelector("[data-autofocus]") ||
        ref.current?.querySelector("input,button,select,textarea")
      )?.focus(),
    );
    function onKey(e) {
      if (e.key === "Escape") closeRef.current();
      if (e.key === "Tab") {
        const focusables = [
          ...(ref.current?.querySelectorAll(
            "button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href]",
          ) || []),
        ].filter((el) => el.offsetParent !== null);
        if (!focusables.length) return;
        const first = focusables[0],
          last = focusables.at(-1);
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    }
    document.addEventListener("keydown", onKey);
    return () => {
      cancelAnimationFrame(frame);
      document.body.style.overflow = oldOverflow;
      document.removeEventListener("keydown", onKey);
      previouslyFocused?.focus();
    };
  }, []);
  return createPortal(
    <motion.div
      className={cx("dialog-backdrop", drawer && "drawer-backdrop")}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <motion.section
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-label={label}
        className={cx("dialog", drawer && "drawer", className)}
        initial={
          drawer ? { x: 70, opacity: 0 } : { y: 24, scale: 0.97, opacity: 0 }
        }
        animate={{ x: 0, y: 0, scale: 1, opacity: 1 }}
        exit={
          drawer ? { x: 70, opacity: 0 } : { y: 12, scale: 0.98, opacity: 0 }
        }
        transition={{ type: "spring", stiffness: 400, damping: 33 }}
      >
        {children}
      </motion.section>
    </motion.div>,
    document.body,
  );
}

function PasswordField({
  label,
  value,
  onChange,
  autoComplete,
  placeholder,
  autoFocus = false,
  id,
}) {
  const [visible, setVisible] = useState(false);
  return (
    <label className="field">
      {label}
      <div className="password-input">
        <input
          id={id}
          data-autofocus={autoFocus || undefined}
          type={visible ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          required
          minLength={autoComplete === "new-password" ? 12 : undefined}
          maxLength={128}
          maxLength={128}
          autoComplete={autoComplete}
          placeholder={placeholder}
        />
        <button
          type="button"
          onClick={() => setVisible(!visible)}
          aria-label={visible ? "Hide password" : "Show password"}
        >
          {visible ? <EyeOff size={17} /> : <Eye size={17} />}
        </button>
      </div>
    </label>
  );
}

function AuthDialog({
  configured,
  onClose,
  onSuccess,
  changePassword = false,
}) {
  const [password, setPassword] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [current, setCurrent] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const setup = !configured && !changePassword;
  async function submit(e) {
    e.preventDefault();
    setError("");
    if ((setup || changePassword) && password !== confirmation) {
      setError("The passwords do not match. Please try again.");
      return;
    }
    setBusy(true);
    try {
      await api(
        changePassword
          ? "/auth/password"
          : setup
            ? "/auth/setup"
            : "/auth/login",
        {
          method: "POST",
          body: changePassword
            ? { current_password: current, new_password: password }
            : { password },
        },
      );
      onSuccess();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Dialog
      label={
        changePassword
          ? "Change admin password"
          : setup
            ? "Set up admin access"
            : "Admin access"
      }
      onClose={onClose}
      className="auth-dialog"
    >
      <button
        className="dialog-close"
        aria-label="Close admin access"
        onClick={onClose}
      >
        <X size={19} />
      </button>
      <div className="auth-symbol">
        <LockKeyhole size={27} strokeWidth={1.65} />
        <span>
          <ShieldCheck size={13} />
        </span>
      </div>
      <div className="eyebrow blue">A LITTLE EXTRA SECURITY</div>
      <h2>
        {changePassword
          ? "A fresh layer of security."
          : setup
            ? "Make this workspace yours."
            : "Welcome back."}
      </h2>
      <p className="auth-description">
        {changePassword
          ? "Choose a new password for your management panel."
          : setup
            ? "Set an admin password to add, edit, and remove officers. You’ll only need to do this once."
            : "Enter your admin password to make changes to the officer directory."}
      </p>
      <form onSubmit={submit}>
        {changePassword && (
          <PasswordField
            label="Current password"
            value={current}
            onChange={setCurrent}
            autoComplete="current-password"
            placeholder="Enter your current password"
            autoFocus
          />
        )}
        <PasswordField
          label={changePassword ? "New password" : "Admin password"}
          value={password}
          onChange={setPassword}
          autoComplete={
            setup || changePassword ? "new-password" : "current-password"
          }
          placeholder={
            setup || changePassword
              ? "At least 12 characters"
              : "Enter your password"
          }
          autoFocus={!changePassword}
          id="admin-password"
        />
        {(setup || changePassword) && (
          <PasswordField
            label="Confirm password"
            value={confirmation}
            onChange={setConfirmation}
            autoComplete="new-password"
            placeholder="Re-enter your password"
          />
        )}
        <AnimatePresence>
          {error && (
            <motion.div
              className="form-error"
              role="alert"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
            >
              {error}
            </motion.div>
          )}
        </AnimatePresence>
        <Button
          type="submit"
          variant="primary"
          className="full-width"
          icon={busy ? Loader2 : setup ? ShieldCheck : UnlockKeyhole}
          disabled={busy}
        >
          {busy
            ? "Please wait…"
            : changePassword
              ? "Update password"
              : setup
                ? "Set password & continue"
                : "Unlock management panel"}
        </Button>
      </form>
      <div className="auth-note">
        <ShieldCheck size={15} />
        <span>Viewing and searching never requires a password.</span>
      </div>
    </Dialog>
  );
}

function OfficerForm({ officer, assignments, onClose, onSave }) {
  const [form, setForm] = useState(
    officer ? { ...officer } : { ...EMPTY_OFFICER },
  );
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const update = (e) =>
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const saved = await api(
        officer ? `/officers/${officer.id}` : "/officers",
        { method: officer ? "PUT" : "POST", body: form },
      );
      onSave(saved, !officer);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Dialog
      label={officer ? "Edit officer" : "Add an officer"}
      onClose={onClose}
      className="officer-dialog"
    >
      <div className="dialog-header">
        <div className="dialog-heading-icon">
          <UserRoundPlus size={20} />
        </div>
        <div>
          <h2>{officer ? "Edit officer" : "Add an officer"}</h2>
          <p>
            {officer
              ? "Update their details. Keep everyone in the loop."
              : "A new face. Everything you need, in one place."}
          </p>
        </div>
        <button
          className="icon-button"
          onClick={onClose}
          aria-label="Close officer form"
        >
          <X size={20} />
        </button>
      </div>
      <form onSubmit={submit}>
        <div className="dialog-body form-grid">
          <div className="form-section-label span-two">
            OFFICER DETAILS <span>Required fields are marked with *</span>
          </div>
          <label className="field span-two">
            Full name <span className="required">*</span>
            <input
              name="name"
              value={form.name}
              onChange={update}
              placeholder="e.g. Alex Morgan"
              required
              minLength={2}
              maxLength={100}
              data-autofocus
            />
          </label>
          <label className="field">
            Badge number <span className="required">*</span>
            <input
              name="badge_id"
              value={form.badge_id}
              onChange={update}
              placeholder="e.g. OF-1080"
              required
              minLength={2}
              maxLength={24}
            />
          </label>
          <label className="field">
            Rank <span className="required">*</span>
            <select name="rank" value={form.rank} onChange={update}>
              {RANKS.map((r) => (
                <option key={r}>{r}</option>
              ))}
            </select>
          </label>
          <label className="field">
            Assignment / unit <span className="required">*</span>
            <input
              name="assignment"
              list="unit-options"
              value={form.assignment}
              onChange={update}
              placeholder="Choose or type a unit"
              required
              maxLength={80}
            />
            <datalist id="unit-options">
              {assignments.map((a) => (
                <option key={a.name} value={a.name} />
              ))}
            </datalist>
          </label>
          <label className="field">
            Status <span className="required">*</span>
            <select name="status" value={form.status} onChange={update}>
              {STATUSES.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </label>
          <div className="form-section-label span-two second-section">
            ADDITIONAL INFORMATION <span>Optional</span>
          </div>
          <label className="field">
            Email address
            <input
              name="email"
              type="email"
              value={form.email}
              onChange={update}
              placeholder="officer@example.com"
              maxLength={150}
            />
          </label>
          <label className="field">
            Phone number
            <input
              name="phone"
              type="tel"
              value={form.phone}
              onChange={update}
              placeholder="Enter phone number"
              maxLength={40}
            />
          </label>
          <label className="field span-two">
            Joined date
            <input
              name="joined_date"
              type="date"
              value={form.joined_date}
              onChange={update}
            />
          </label>
          <label className="field span-two">
            Notes
            <textarea
              name="notes"
              aria-label="Notes"
              value={form.notes}
              onChange={update}
              placeholder="Anything else the team should know…"
              rows={3}
              maxLength={2000}
            />
          </label>
          {error && (
            <div role="alert" className="form-error span-two">
              {error}
            </div>
          )}
        </div>
        <div className="dialog-footer">
          <span>
            <LockKeyhole size={13} /> Protected admin action
          </span>
          <div>
            <Button type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              icon={busy ? Loader2 : Check}
              disabled={busy}
            >
              {busy ? "Saving…" : officer ? "Save changes" : "Add officer"}
            </Button>
          </div>
        </div>
      </form>
    </Dialog>
  );
}

function OfficerProfile({ officer, onClose, onEdit, onDelete, authenticated }) {
  return (
    <Dialog label={`${officer.name} profile`} onClose={onClose} drawer>
      <div className="profile-top">
        <span className="eyebrow">OFFICER PROFILE</span>
        <button
          className="icon-button"
          onClick={onClose}
          aria-label="Close officer profile"
        >
          <X size={20} />
        </button>
      </div>
      <div className="profile-cover">
        <span />
        <span />
      </div>
      <div className="profile-identity">
        <Avatar name={officer.name} large />
        <h2>{officer.name}</h2>
        <p>
          {officer.rank}
          <span>·</span>
          {officer.badge_id}
        </p>
        <StatusPill status={officer.status} />
      </div>
      <div className="profile-actions">
        <Button icon={Pencil} onClick={() => onEdit(officer)}>
          {authenticated ? "Edit details" : "Unlock to edit"}
          {!authenticated && <LockKeyhole size={13} />}
        </Button>
        <Button
          icon={Trash2}
          variant="quiet-danger"
          onClick={() => onDelete([officer])}
          aria-label="Remove officer"
        />
      </div>
      <div className="profile-section">
        <h3>At a glance</h3>
        <div className="profile-detail">
          <Building2 size={17} />
          <div>
            <span>Assignment / unit</span>
            <strong>{officer.assignment}</strong>
          </div>
        </div>
        <div className="profile-detail">
          <BadgeCheck size={17} />
          <div>
            <span>Badge number</span>
            <strong>{officer.badge_id}</strong>
          </div>
        </div>
        <div className="profile-detail">
          <UserRoundCheck size={17} />
          <div>
            <span>Joined date</span>
            <strong>{humanDate(officer.joined_date)}</strong>
          </div>
        </div>
      </div>
      <div className="profile-section">
        <h3>Contact information</h3>
        <div className="profile-detail">
          <Mail size={17} />
          <div>
            <span>Email address</span>
            {officer.email ? (
              <a href={`mailto:${encodeURIComponent(officer.email).replace(/%40/g, "@")}`}>
                {officer.email}
              </a>
            ) : (
              <strong className="muted">Not provided</strong>
            )}
          </div>
        </div>
        <div className="profile-detail">
          <Phone size={17} />
          <div>
            <span>Phone number</span>
            {officer.phone ? (
              <a href={`tel:${officer.phone.replace(/[^\d+]/g, "")}`}>
                {officer.phone}
              </a>
            ) : (
              <strong className="muted">Not provided</strong>
            )}
          </div>
        </div>
      </div>
      {officer.notes && (
        <div className="profile-section">
          <h3>Notes</h3>
          <p className="profile-notes">{officer.notes}</p>
        </div>
      )}
      <div className="profile-bottom">
        <Database size={13} />
        Last updated {humanDate(officer.updated_at)}
        {!!officer.is_demo && (
          <span className="sample-chip">Sample record</span>
        )}
      </div>
    </Dialog>
  );
}

function DeleteDialog({ officers, onClose, onDeleted }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function remove() {
    setBusy(true);
    setError("");
    try {
      if (officers.length === 1)
        await api(`/officers/${officers[0].id}`, { method: "DELETE" });
      else
        await api("/officers/bulk-delete", {
          method: "POST",
          body: { ids: officers.map((o) => o.id) },
        });
      onDeleted(officers.length);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Dialog label="Confirm removal" onClose={onClose} className="delete-dialog">
      <div className="delete-symbol">
        <Trash2 size={24} />
      </div>
      <h2>
        {officers.length === 1
          ? `Remove ${officers[0].name}?`
          : `Remove ${officers.length} officers?`}
      </h2>
      <p>
        {officers.length === 1 ? "This officer" : "These officers"} will be
        permanently removed from the directory. This action can’t be undone.
      </p>
      {error && (
        <div className="form-error" role="alert">
          {error}
        </div>
      )}
      <div className="delete-actions">
        <Button onClick={onClose} disabled={busy}>
          Keep {officers.length === 1 ? "officer" : "officers"}
        </Button>
        <Button
          variant="danger"
          icon={busy ? Loader2 : Trash2}
          onClick={remove}
          disabled={busy}
        >
          {busy
            ? "Removing…"
            : `Remove ${officers.length === 1 ? "officer" : "officers"}`}
        </Button>
      </div>
    </Dialog>
  );
}

function StatsCards({ stats, activeStatus, onFilter }) {
  const cards = [
    {
      label: "Total officers",
      value: stats?.total,
      detail: `Across ${stats?.assignments?.length ?? 0} assignments`,
      icon: UsersRound,
      color: "blue",
      status: "",
    },
    {
      label: "On duty",
      value: stats?.on_duty,
      detail: "Currently on active duty",
      icon: UserRoundCheck,
      color: "green",
      status: "On duty",
    },
    {
      label: "Off duty",
      value: stats?.off_duty,
      detail: "Outside their active shift",
      icon: UserRound,
      color: "slate",
      status: "Off duty",
    },
    {
      label: "On leave",
      value: stats?.on_leave,
      detail: "Taking some time away",
      icon: ArrowDownLeft,
      color: "amber",
      status: "On leave",
    },
  ];
  return (
    <div className="stats-grid">
      {cards.map((c, i) => (
        <motion.button
          key={c.label}
          className={cx(
            "stat-card",
            activeStatus && activeStatus === c.status && "stat-card-selected",
          )}
          onClick={() => onFilter(c.status)}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.045 }}
          whileHover={{ y: -2 }}
          whileTap={{ scale: 0.99 }}
        >
          <div className="stat-top">
            <span>{c.label}</span>
            <span className={cx("stat-icon", c.color)}>
              <c.icon size={17} strokeWidth={1.7} />
            </span>
          </div>
          <div className="stat-value">
            {c.value ?? <span className="skeleton skeleton-number" />}
            {c.status === "On duty" && (
              <span className="stat-live">
                <i />
                LIVE
              </span>
            )}
          </div>
          <div className="stat-bottom">
            {c.detail}
            <ChevronRight size={13} />
          </div>
        </motion.button>
      ))}
    </div>
  );
}

function ActivityItem({ item, compact = false }) {
  const Icon =
    item.action === "created"
      ? UserRoundPlus
      : item.action === "updated"
        ? Pencil
        : item.action === "deleted"
          ? Trash2
          : item.action === "security"
            ? ShieldCheck
            : Sparkles;
  let details = {};
  try {
    details = JSON.parse(item.details);
  } catch {}
  return (
    <div className={cx("activity-item", compact && "compact")}>
      <span className={cx("activity-icon", item.action)}>
        <Icon size={16} />
      </span>
      <div className="activity-copy">
        <p>{item.message}</p>
        <span>
          {item.actor}
          {!compact && details.fields?.length
            ? ` · Changed ${details.fields.map((f) => f.replace("_", " ")).join(", ")}`
            : ""}
        </span>
      </div>
      <time title={humanDate(item.created_at)}>
        {relativeTime(item.created_at)}
      </time>
    </div>
  );
}

function Overview({ stats, onNavigate, onStatus, onAdd, onExport }) {
  const total = stats?.total || 0;
  const on = stats?.on_duty || 0,
    off = stats?.off_duty || 0;
  const maxUnits = Math.max(
    1,
    ...(stats?.assignments || []).map((a) => a.count),
  );
  return (
    <motion.div
      className="overview-content"
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className="overview-grid">
        <section className="panel assignment-panel">
          <div className="panel-title">
            <div>
              <h2>People, in the right places.</h2>
              <p>Your team by assignment</p>
            </div>
            <Building2 size={18} />
          </div>
          <div className="unit-chart">
            {(stats?.assignments || []).map((a, i) => (
              <button
                className="unit-row"
                key={a.name}
                onClick={() => onNavigate("directory", a.name)}
              >
                <div>
                  <span>{a.name}</span>
                  <strong>
                    {a.count}
                    <ChevronRight size={12} />
                  </strong>
                </div>
                <div className="unit-track">
                  <motion.span
                    initial={{ width: 0 }}
                    animate={{ width: `${(a.count / maxUnits) * 100}%` }}
                    transition={{ duration: 0.7, delay: i * 0.06 }}
                    style={{ opacity: 1 - i * 0.09 }}
                  />
                </div>
              </button>
            ))}
            {!total && (
              <p className="muted">
                Add your first officer to see assignment insights.
              </p>
            )}
          </div>
        </section>
        <section className="panel availability-panel">
          <div className="panel-title">
            <div>
              <h2>Ready for the day.</h2>
              <p>Real-time officer availability</p>
            </div>
            <Activity size={18} />
          </div>
          <div
            className="donut"
            style={{
              background: total
                ? `conic-gradient(#3478f6 0 ${(on / total) * 100}%, #c5d4f5 ${(on / total) * 100}% ${((on + off) / total) * 100}%, #f6ca77 ${((on + off) / total) * 100}% 100%)`
                : "#e8ebf0",
            }}
          >
            <div>
              <strong>
                {total ? Math.round((on / total) * 100) : 0}
                <small>%</small>
              </strong>
              <span>on duty</span>
            </div>
          </div>
          <div className="donut-legend">
            {STATUSES.map((s, i) => (
              <button key={s} onClick={() => onStatus(s)}>
                <i
                  style={{ background: ["#3478f6", "#c5d4f5", "#f6ca77"][i] }}
                />
                <span>{s}</span>
                <strong>
                  {[stats?.on_duty, stats?.off_duty, stats?.on_leave][i] ?? 0}
                </strong>
              </button>
            ))}
          </div>
        </section>
      </div>
      <div className="overview-grid second-grid">
        <section className="panel">
          <div className="panel-title">
            <div>
              <h2>A little history.</h2>
              <p>The latest in your workspace</p>
            </div>
            <button
              className="text-button"
              onClick={() => onNavigate("activity")}
            >
              View all
              <ArrowRight size={14} />
            </button>
          </div>
          <div className="recent-activity">
            {(stats?.recent_activity || []).map((item) => (
              <ActivityItem item={item} key={item.id} compact />
            ))}
          </div>
        </section>
        <section className="quick-actions">
          <span className="eyebrow">A GOOD PLACE TO START</span>
          <h2>
            Less admin.
            <br />
            More getting things done.
          </h2>
          <p>Your directory, always a little more organized.</p>
          <Button variant="primary" icon={Plus} onClick={onAdd}>
            Add an officer
          </Button>
          <button
            className="text-button"
            onClick={() => onExport("xlsx", true)}
          >
            Take your data with you
            <ArrowRight size={14} />
          </button>
          <div className="quick-decor">
            <ShieldCheck size={100} strokeWidth={0.8} />
          </div>
        </section>
      </div>
    </motion.div>
  );
}

function ExportPage({
  stats,
  filteredTotal,
  filtersActive,
  onExport,
  exporting,
}) {
  const [scope, setScope] = useState("all");
  const rows = scope === "all" ? (stats?.total ?? 0) : filteredTotal;
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="export-page"
    >
      <div className="export-scope panel">
        <div className="export-scope-icon">
          <ListFilter size={21} />
        </div>
        <div>
          <h2>Choose what comes with you.</h2>
          <p>Export every officer, or just your current directory view.</p>
        </div>
        <select
          value={scope}
          onChange={(e) => setScope(e.target.value)}
          aria-label="Export scope"
        >
          <option value="all">All officers ({stats?.total ?? 0})</option>
          <option value="filtered">Current view ({filteredTotal})</option>
        </select>
      </div>
      <div className="export-cards">
        {[
          {
            format: "csv",
            name: "CSV file",
            tag: ".CSV",
            description:
              "Simple, lightweight, and ready for almost anything. Import into Sheets or your favorite tools.",
            Icon: FileText,
            color: "blue",
          },
          {
            format: "xlsx",
            name: "Excel workbook",
            tag: ".XLSX",
            description:
              "A beautifully formatted spreadsheet with a frozen header, filters, and all your officer details.",
            Icon: FileSpreadsheet,
            color: "green",
          },
        ].map(({ format, name, tag, description, Icon, color }) => (
          <section className="panel export-card" key={format}>
            <div className={cx("export-file-graphic", color)}>
              <Icon size={39} strokeWidth={1.25} />
              <span>{tag}</span>
            </div>
            <h2>{name}</h2>
            <p>{description}</p>
            <div className="export-file-details">
              <span>
                <CheckCheck size={14} />
                {rows} officer records
              </span>
              <span>
                <Columns3 size={14} />9 data columns
              </span>
            </div>
            <Button
              variant="secondary"
              icon={exporting === format ? Loader2 : Download}
              onClick={() => onExport(format, scope === "all")}
              disabled={!!exporting}
            >
              Download {format === "csv" ? "CSV" : "Excel"}
              <ArrowDownToLine size={15} />
            </Button>
          </section>
        ))}
      </div>
      <div className="export-note">
        <ShieldCheck size={17} />
        <div>
          <strong>Your data stays yours.</strong>
          <p>
            Exports include contact details and notes. Keep downloaded files in
            a safe place.
            {scope === "filtered" && filtersActive
              ? " Your current search, filters, and sort order are included."
              : ""}
          </p>
        </div>
      </div>
    </motion.div>
  );
}

function ActivityPage({ revision }) {
  const [action, setAction] = useState("");
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => {
    const controller = new AbortController();
    api(`/activity?page=${page}&action=${action}`, {
      signal: controller.signal,
    })
      .then(setData)
      .catch((e) => {
        if (e.name !== "AbortError") setError(e.message);
      });
    return () => controller.abort();
  }, [action, page, revision]);
  return (
    <motion.section
      className="panel activity-panel"
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className="activity-toolbar">
        <div>
          <span className="small-dot" />A record of every change
          <span className="count-badge">{data?.total ?? 0}</span>
        </div>
        <select
          aria-label="Filter activity"
          value={action}
          onChange={(e) => {
            setAction(e.target.value);
            setPage(1);
          }}
        >
          <option value="">All activity</option>
          <option value="created">Officers added</option>
          <option value="updated">Officers updated</option>
          <option value="deleted">Officers removed</option>
          <option value="security">Security</option>
          <option value="workspace">Workspace</option>
        </select>
      </div>
      {error && (
        <div role="alert" className="form-error">
          {error}
        </div>
      )}
      <div className="activity-list">
        {!data ? (
          <div className="loading-panel">
            <Loader2 className="spin" size={20} />
            Loading activity…
          </div>
        ) : data.items.length ? (
          data.items.map((item) => <ActivityItem key={item.id} item={item} />)
        ) : (
          <div className="empty-state">
            <Activity size={27} />
            <h2>A clean slate.</h2>
            <p>Changes to your directory will appear here.</p>
          </div>
        )}
      </div>
      {data && (
        <div className="table-footer">
          <span>
            {data.total} {data.total === 1 ? "event" : "events"} in this view
          </span>
          <div className="pagination">
            <button
              aria-label="Previous activity page"
              disabled={page <= 1}
              onClick={() => setPage((p) => p - 1)}
            >
              <ChevronLeft size={16} />
            </button>
            <span>
              Page {data.page} of {data.pages}
            </span>
            <button
              aria-label="Next activity page"
              disabled={page >= data.pages}
              onClick={() => setPage((p) => p + 1)}
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}
    </motion.section>
  );
}

export default function App() {
  const [view, setView] = useState(() =>
    ["directory", "overview", "activity", "exports"].includes(
      location.hash.slice(1),
    )
      ? location.hash.slice(1)
      : "directory",
  );
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(
    () => window.matchMedia("(max-width: 820px)").matches,
  );
  useEffect(() => {
    const media = window.matchMedia("(max-width: 820px)");
    const listener = () => setIsMobile(media.matches);
    media.addEventListener("change", listener);
    return () => media.removeEventListener("change", listener);
  }, []);
  const [auth, setAuth] = useState({
    authenticated: false,
    configured: true,
    loaded: false,
    public_view: true,
  });
  // Private mode: the server withholds all directory data until sign-in.
  const locked =
    auth.loaded && !auth.authenticated && auth.public_view === false;
  const [stats, setStats] = useState(null);
  const [data, setData] = useState({
    officers: [],
    total: 0,
    page: 1,
    pages: 1,
    page_size: 8,
  });
  const [search, setSearch] = useState("");
  const q = useDebounced(search);
  const [filters, setFilters] = useState({
    status: "",
    rank: "",
    assignment: "",
  });
  const [sort, setSort] = useState({ column: "name", direction: "asc" });
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(8);
  const [columns, setColumns] = useState(COLUMNS.map((c) => c.key));
  const [selected, setSelected] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [revision, setRevision] = useState(0);
  const [modal, setModal] = useState(null);
  const [officer, setOfficer] = useState(null);
  const [deleting, setDeleting] = useState([]);
  const [toasts, setToasts] = useState([]);
  const [exporting, setExporting] = useState(null);
  const pendingAction = useRef(null);
  const searchRef = useRef(null);
  const filterCount = Object.values(filters).filter(Boolean).length;
  const directoryView = view === "directory" || view === "manage";

  function notify(message, type = "success") {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-2), { id, message, type }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4500);
  }
  useEffect(() => {
    const controller = new AbortController();
    api("/auth/status", { signal: controller.signal })
      .then(async (a) => {
        setAuth({ ...a, loaded: true });
        if (a.authenticated || a.public_view !== false) {
          setStats(await api("/stats", { signal: controller.signal }));
        }
      })
      .catch((e) => {
        if (e.name !== "AbortError") {
          setLoadError(e.message);
          setAuth((a) => ({ ...a, loaded: true }));
        }
      });
    return () => controller.abort();
  }, []);
  useEffect(() => {
    if (!auth.loaded || locked) return;
    const controller = new AbortController();
    api("/stats", { signal: controller.signal })
      .then(setStats)
      .catch((e) => {
        if (e.name === "AbortError") return;
        if (e.status === 401) setAuth((a) => ({ ...a, authenticated: false }));
        else setLoadError(e.message);
      });
    return () => controller.abort();
  }, [revision, locked, auth.loaded]);
  const queryParams = (all = false) =>
    new URLSearchParams({
      q: all ? "" : q,
      status: all ? "" : filters.status,
      rank: all ? "" : filters.rank,
      assignment: all ? "" : filters.assignment,
      sort: sort.column,
      direction: sort.direction,
    });
  useEffect(() => {
    if (!auth.loaded || locked) return;
    const controller = new AbortController();
    setLoading(true);
    setLoadError("");
    const params = queryParams();
    params.set("page", page);
    params.set("page_size", pageSize);
    api(`/officers?${params}`, { signal: controller.signal })
      .then((d) => {
        setData(d);
        setLoading(false);
        if (d.page !== page) setPage(d.page);
      })
      .catch((e) => {
        if (e.name === "AbortError") return;
        if (e.status === 401) {
          // Session expired: return to the sign-in screen in private mode.
          setAuth((a) => ({ ...a, authenticated: false }));
        } else {
          setLoadError(e.message);
        }
        setLoading(false);
      });
    return () => controller.abort();
  }, [q, filters, sort, page, pageSize, revision, locked, auth.loaded]);
  useEffect(() => {
    setSelected(new Set());
  }, [q, filters, sort, page, pageSize]);
  useEffect(() => {
    document.title = `${VIEW_LABELS[view]} — Roster`;
    location.hash = view;
  }, [view]);
  useEffect(() => {
    const hashChange = () => {
      const requested = location.hash.slice(1);
      if (
        VIEW_LABELS[requested] &&
        (requested !== "manage" || auth.authenticated)
      )
        setView(requested);
    };
    window.addEventListener("hashchange", hashChange);
    return () => window.removeEventListener("hashchange", hashChange);
  }, [auth.authenticated]);
  useEffect(() => {
    const key = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setView("directory");
        setTimeout(() => searchRef.current?.focus(), 40);
      }
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, []);

  function navigate(next, assignment) {
    if (next === "manage" && !auth.authenticated) {
      requireAdmin(() => {
        setView("manage");
        setSidebarOpen(false);
      });
      return;
    }
    setView(next);
    setSidebarOpen(false);
    if (assignment) {
      setFilters({ status: "", rank: "", assignment });
      setPage(1);
    }
  }
  function requireAdmin(action) {
    if (auth.authenticated) action();
    else {
      pendingAction.current = action;
      setModal("auth");
    }
  }
  function openAdd() {
    requireAdmin(() => {
      setOfficer(null);
      setModal("officer");
    });
  }
  function openEdit(o) {
    requireAdmin(() => {
      setOfficer(o);
      setModal("officer");
    });
  }
  function openDelete(items) {
    requireAdmin(() => {
      setDeleting(items);
      setModal("delete");
    });
  }
  function openProfile(o) {
    setOfficer(o);
    setModal("profile");
  }
  function setStatus(status) {
    setFilters((f) => ({ ...f, status }));
    setPage(1);
    if (!directoryView) setView("directory");
  }
  function setFilter(key, value) {
    setFilters((f) => ({ ...f, [key]: value }));
    setPage(1);
  }
  function clearFilters() {
    setFilters({ status: "", rank: "", assignment: "" });
    setSearch("");
    setPage(1);
  }
  function toggleSort(column) {
    setSort((s) => ({
      column,
      direction: s.column === column && s.direction === "asc" ? "desc" : "asc",
    }));
    setPage(1);
  }
  function toggleSelected(id) {
    setSelected((s) => {
      const next = new Set(s);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }
  function authSuccess() {
    setAuth({ authenticated: true, configured: true, loaded: true });
    setModal(null);
    setRevision((r) => r + 1);
    notify(
      modal === "password"
        ? "Your admin password has been updated."
        : "Admin access unlocked. You’re in control.",
    );
    if (pendingAction.current) {
      const action = pendingAction.current;
      pendingAction.current = null;
      action();
    }
  }
  function closeModal() {
    setModal(null);
    if (modal === "auth") pendingAction.current = null;
  }
  async function signOut() {
    try {
      await api("/auth/logout", { method: "POST", body: {} });
      setAuth((a) => ({ ...a, authenticated: false }));
      if (view === "manage") setView("directory");
      notify(
        auth.public_view === false
          ? "Signed out."
          : "Signed out. Your directory is still available to view.",
      );
    } catch (err) {
      notify(err.message, "error");
    }
  }
  async function exportFile(format, all = false) {
    setExporting(format);
    try {
      const response = await fetch(`/api/export/${format}?${queryParams(all)}`);
      if (!response.ok)
        throw new Error("Could not export the directory. Please try again.");
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download =
        response.headers
          .get("Content-Disposition")
          ?.match(/filename="?([^";]+)/)?.[1] || `roster-officers.${format}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 15000);
      notify(
        `${format === "csv" ? "CSV file" : "Excel workbook"} downloaded. Your data, ready to go.`,
      );
    } catch (err) {
      notify(err.message, "error");
    } finally {
      setExporting(null);
    }
  }

  const navItems = [
    { id: "overview", label: "Overview", icon: LayoutDashboard },
    { id: "directory", label: "Officer directory", icon: UsersRound },
    { id: "activity", label: "Activity log", icon: Activity },
  ];
  const statuses = [
    { label: "All officers", status: "", count: stats?.total },
    { label: "On duty", status: "On duty", count: stats?.on_duty },
    { label: "Off duty", status: "Off duty", count: stats?.off_duty },
    { label: "On leave", status: "On leave", count: stats?.on_leave },
  ];
  const subtitles = {
    directory: "Good people. One organized place.",
    manage: "Your team, your control. Make every detail count.",
    overview: "A little clarity for the day ahead.",
    activity: "Every update, all in one place.",
    exports: "Your directory. Ready to go wherever you do.",
  };
  const shownColumns = COLUMNS.filter((c) => columns.includes(c.key));
  const allSelected =
    data.officers.length > 0 && data.officers.every((o) => selected.has(o.id));
  const displayedPages = Array.from(
    { length: data.pages },
    (_, i) => i + 1,
  ).filter(
    (n) =>
      data.pages <= 6 ||
      n === 1 ||
      n === data.pages ||
      Math.abs(n - data.page) <= 1,
  );

  if (locked) {
    return (
      <MotionConfig
        reducedMotion="user"
        transition={{ type: "spring", stiffness: 400, damping: 32 }}
      >
        <div className="app-shell" aria-hidden="true" />
        <AuthDialog
          configured={auth.configured}
          onClose={() => {}}
          onSuccess={authSuccess}
        />
      </MotionConfig>
    );
  }

  return (
    <MotionConfig
      reducedMotion="user"
      transition={{ type: "spring", stiffness: 400, damping: 32 }}
    >
      <div className="app-shell" inert={modal ? true : undefined}>
        {sidebarOpen && (
          <div
            className="sidebar-scrim"
            onClick={() => setSidebarOpen(false)}
          />
        )}
        <aside
          className={cx("sidebar", sidebarOpen && "sidebar-open")}
          inert={isMobile && !sidebarOpen ? true : undefined}
          aria-hidden={isMobile && !sidebarOpen ? true : undefined}
        >
          <div className="sidebar-brand">
            <Logo />
            <button
              className="icon-button mobile-only"
              aria-label="Close navigation"
              onClick={() => setSidebarOpen(false)}
            >
              <X size={20} />
            </button>
          </div>
          <div className="workspace-selector">
            <span className="workspace-icon">
              <Shield size={17} strokeWidth={1.8} />
            </span>
            <div>
              <strong>Officer workspace</strong>
              <span>Your team, connected</span>
            </div>
            <span className="workspace-initial">01</span>
          </div>
          <div className="nav-section-title">WORKSPACE</div>
          <nav aria-label="Main navigation">
            {navItems.map(({ id, label, icon: Icon }) => (
              <button
                aria-label={label}
                aria-current={view === id ? "page" : undefined}
                className={cx("nav-item", view === id && "active")}
                key={id}
                onClick={() => navigate(id)}
              >
                {view === id && (
                  <motion.span
                    layoutId="nav-highlight"
                    className="nav-highlight"
                  />
                )}
                <Icon size={18} strokeWidth={1.7} />
                <span>{label}</span>
                {id === "directory" && (
                  <span className="nav-count">{stats?.total ?? "—"}</span>
                )}
              </button>
            ))}
          </nav>
          <div className="nav-section-title tools-title">TOOLS</div>
          <nav aria-label="Workspace tools">
            <button
              className={cx("nav-item", view === "exports" && "active")}
              onClick={() => navigate("exports")}
            >
              {view === "exports" && (
                <motion.span
                  layoutId="nav-highlight"
                  className="nav-highlight"
                />
              )}
              <Download size={18} strokeWidth={1.7} />
              <span>Exports</span>
            </button>
            <button
              className={cx("nav-item", view === "manage" && "active")}
              onClick={() => navigate("manage")}
            >
              {view === "manage" && (
                <motion.span
                  layoutId="nav-highlight"
                  className="nav-highlight"
                />
              )}
              <SlidersHorizontal size={18} strokeWidth={1.7} />
              <span>Manage officers</span>
              {auth.authenticated ? (
                <span className="nav-unlocked">
                  <UnlockKeyhole size={12} />
                </span>
              ) : (
                <LockKeyhole size={12} className="nav-lock" />
              )}
            </button>
          </nav>
          <div className="sidebar-bottom">
            <div className="storage-card">
              <div className="storage-icon">
                <Database size={17} />
                <span />
              </div>
              <div>
                <strong>Safe. Saved. Always.</strong>
                <span>Persistent database storage</span>
              </div>
              <div className="storage-footer">
                <i />
                {loadError
                  ? "Connection interrupted"
                  : "All changes saved automatically"}
                <ShieldCheck size={12} />
              </div>
            </div>
            <button className="help-link" onClick={() => setModal("help")}>
              <CircleHelp size={16} />
              <span>A little help</span>
              <ArrowRight size={13} />
            </button>
            <div className="sidebar-user">
              <span
                className={cx("user-badge", auth.authenticated && "is-admin")}
              >
                {auth.authenticated ? (
                  <ShieldCheck size={18} />
                ) : (
                  <UserRound size={18} />
                )}
              </span>
              <button
                onClick={() =>
                  auth.authenticated ? navigate("manage") : navigate("manage")
                }
              >
                <strong>
                  {auth.authenticated ? "Administrator" : "Guest workspace"}
                </strong>
                <span>
                  {auth.authenticated
                    ? "Management unlocked"
                    : "View-only access"}
                </span>
              </button>
              {auth.authenticated ? (
                <button
                  className="icon-button logout-button"
                  onClick={signOut}
                  aria-label="Sign out"
                  title="Sign out"
                >
                  <LogOut size={16} />
                </button>
              ) : (
                <LockKeyhole size={14} />
              )}
            </div>
          </div>
        </aside>
        <div className="main-shell">
          <header className="topbar">
            <div className="breadcrumbs">
              <button
                className="icon-button mobile-only"
                aria-label="Open navigation"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu size={21} />
              </button>
              <span className="breadcrumb-icon">
                <Grid2X2 size={15} />
              </span>
              <span>Workspace</span>
              <ChevronRight size={13} />
              <strong>{VIEW_LABELS[view]}</strong>
            </div>
            <div className="topbar-right">
              <span className="live-connection">
                <i />
                Database connected
              </span>
              <span className="topbar-separator" />
              {auth.authenticated ? (
                <Dropdown
                  label="Admin account"
                  className="admin-menu-trigger"
                  trigger={
                    <>
                      <span className="admin-mini-avatar">
                        <ShieldCheck size={14} />
                      </span>
                      <span>Administrator</span>
                      <ChevronDown size={12} />
                    </>
                  }
                >
                  {(close) => (
                    <>
                      <div className="menu-caption">ADMIN ACCOUNT</div>
                      <button
                        className="menu-item"
                        onClick={() => {
                          close();
                          setModal("password");
                        }}
                      >
                        <Fingerprint size={16} />
                        Change password
                      </button>
                      <button
                        className="menu-item"
                        onClick={() => {
                          close();
                          signOut();
                        }}
                      >
                        <LogOut size={16} />
                        Sign out
                      </button>
                    </>
                  )}
                </Dropdown>
              ) : (
                <button
                  className="admin-access"
                  onClick={() => navigate("manage")}
                  disabled={!auth.loaded}
                >
                  <LockKeyhole size={14} />
                  Admin access
                  <ArrowRight size={13} />
                </button>
              )}
            </div>
          </header>
          <main className="main-content">
            <div className="page-heading">
              <div>
                <div className="page-eyebrow">
                  <span />
                  YOUR TEAM, AT A GLANCE
                </div>
                <h1>
                  {VIEW_LABELS[view]}
                  <span className="heading-dot">.</span>
                  {view === "manage" && (
                    <span className="admin-mode-chip">
                      <ShieldCheck size={12} />
                      Admin mode
                    </span>
                  )}
                </h1>
                <p>{subtitles[view]}</p>
              </div>
              <div className="heading-actions">
                {directoryView || view === "overview" ? (
                  <>
                    <Dropdown
                      label="Export officers"
                      className="button button-secondary"
                      disabled={!!exporting}
                      trigger={
                        <>
                          {exporting ? (
                            <Loader2 size={16} className="spin" />
                          ) : (
                            <ArrowDownToLine size={16} />
                          )}
                          <span>Export</span>
                          <ChevronDown size={14} />
                        </>
                      }
                    >
                      {(close) => (
                        <>
                          <div className="menu-caption">
                            TAKE YOUR DATA WITH YOU
                          </div>
                          <button
                            className="menu-item"
                            onClick={() => {
                              close();
                              exportFile("csv");
                            }}
                          >
                            <FileText size={17} />
                            <div>
                              <strong>Export as CSV</strong>
                              <span>For Sheets & other tools</span>
                            </div>
                            <span className="file-label">.csv</span>
                          </button>
                          <button
                            className="menu-item"
                            onClick={() => {
                              close();
                              exportFile("xlsx");
                            }}
                          >
                            <FileSpreadsheet size={17} />
                            <div>
                              <strong>Export as Excel</strong>
                              <span>A formatted workbook</span>
                            </div>
                            <span className="file-label">.xlsx</span>
                          </button>
                          <div className="menu-note">
                            Includes all matching officers.
                          </div>
                        </>
                      )}
                    </Dropdown>
                    <Button
                      variant="primary"
                      icon={Plus}
                      onClick={openAdd}
                      disabled={!auth.loaded}
                    >
                      Add officer
                    </Button>
                  </>
                ) : (
                  <Button
                    icon={UsersRound}
                    onClick={() => navigate("directory")}
                  >
                    Back to directory
                  </Button>
                )}
              </div>
            </div>
            {view !== "exports" && view !== "activity" && (
              <StatsCards
                stats={stats}
                activeStatus={directoryView ? filters.status : ""}
                onFilter={setStatus}
              />
            )}
            {loadError && (
              <div className="connection-error" role="alert">
                <Database size={17} />
                {loadError}
                <Button onClick={() => setRevision((r) => r + 1)}>
                  Try again
                </Button>
              </div>
            )}
            {directoryView && (
              <motion.section
                className="directory-section"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <div className="directory-tabs">
                  <div
                    className="tabs"
                    role="tablist"
                    aria-label="Officer status"
                  >
                    {statuses.map((t) => (
                      <button
                        role="tab"
                        aria-selected={filters.status === t.status}
                        className={cx(
                          "tab",
                          filters.status === t.status && "active",
                        )}
                        key={t.label}
                        onClick={() => setStatus(t.status)}
                      >
                        {t.label}
                        <span>{t.count ?? "—"}</span>
                        {filters.status === t.status && (
                          <motion.i
                            className="tab-underline"
                            layoutId="status-tab"
                          />
                        )}
                      </button>
                    ))}
                  </div>
                  <span
                    className={cx(
                      "view-access",
                      auth.authenticated && "unlocked",
                    )}
                  >
                    {auth.authenticated ? (
                      <UnlockKeyhole size={12} />
                    ) : (
                      <Eye size={13} />
                    )}
                    {auth.authenticated ? "Edits unlocked" : "Public view"}
                  </span>
                </div>
                <div className="table-panel">
                  <div className="table-toolbar">
                    <div className="search-box">
                      <Search size={17} strokeWidth={1.8} />
                      <input
                        ref={searchRef}
                        aria-label="Search officers"
                        placeholder="Search by name, badge, or assignment…"
                        value={search}
                        onChange={(e) => {
                          setSearch(e.target.value);
                          setPage(1);
                        }}
                      />
                      {search ? (
                        <button
                          aria-label="Clear search"
                          onClick={() => {
                            setSearch("");
                            setPage(1);
                            searchRef.current?.focus();
                          }}
                        >
                          <X size={14} />
                        </button>
                      ) : (
                        <kbd>
                          <Command size={10} />K
                        </kbd>
                      )}
                    </div>
                    <Dropdown
                      label="Filter officers"
                      className={cx(
                        "button button-secondary filter-button",
                        filterCount > 0 && "has-filters",
                      )}
                      align="left"
                      trigger={
                        <>
                          <ListFilter size={16} />
                          <span>Filters</span>
                          {filterCount > 0 && (
                            <span className="filter-count">{filterCount}</span>
                          )}
                        </>
                      }
                    >
                      {(close) => (
                        <div className="filter-popover">
                          <div className="filter-popover-title">
                            <strong>Make it a little more specific.</strong>
                            <button
                              className="icon-button"
                              aria-label="Close filters"
                              onClick={close}
                            >
                              <X size={15} />
                            </button>
                          </div>
                          <label className="field">
                            Duty status
                            <select
                              aria-label="Filter by status"
                              value={filters.status}
                              onChange={(e) =>
                                setFilter("status", e.target.value)
                              }
                            >
                              <option value="">All statuses</option>
                              {STATUSES.map((s) => (
                                <option key={s}>{s}</option>
                              ))}
                            </select>
                          </label>
                          <label className="field">
                            Rank
                            <select
                              aria-label="Filter by rank"
                              value={filters.rank}
                              onChange={(e) =>
                                setFilter("rank", e.target.value)
                              }
                            >
                              <option value="">All ranks</option>
                              {RANKS.map((r) => (
                                <option key={r}>{r}</option>
                              ))}
                            </select>
                          </label>
                          <label className="field">
                            Assignment
                            <select
                              aria-label="Filter by assignment"
                              value={filters.assignment}
                              onChange={(e) =>
                                setFilter("assignment", e.target.value)
                              }
                            >
                              <option value="">All assignments</option>
                              {(stats?.assignments || []).map((a) => (
                                <option key={a.name}>{a.name}</option>
                              ))}
                            </select>
                          </label>
                          <div className="filter-popover-bottom">
                            <button
                              className="text-button"
                              onClick={() =>
                                setFilters({
                                  status: "",
                                  rank: "",
                                  assignment: "",
                                })
                              }
                            >
                              Reset filters
                            </button>
                            <Button variant="primary" onClick={close}>
                              Done
                              <Check size={13} />
                            </Button>
                          </div>
                        </div>
                      )}
                    </Dropdown>
                    <span className="toolbar-spacer" />
                    <span className="sort-summary">
                      <ArrowUpDown size={13} />
                      {COLUMNS.find((c) => c.key === sort.column)?.label ||
                        "Name"}{" "}
                      {sort.direction === "asc" ? "A–Z" : "Z–A"}
                    </span>
                    <div className="toolbar-divider" />
                    <Dropdown
                      label="Visible columns"
                      className="columns-trigger"
                      trigger={
                        <>
                          <Columns3 size={16} />
                          <ChevronDown size={12} />
                        </>
                      }
                    >
                      {() => (
                        <>
                          <div className="menu-caption">VISIBLE COLUMNS</div>
                          {COLUMNS.map((c) => (
                            <label className="column-choice" key={c.key}>
                              <input
                                type="checkbox"
                                checked={columns.includes(c.key)}
                                disabled={c.key === "name"}
                                onChange={(e) =>
                                  setColumns((cols) =>
                                    e.target.checked
                                      ? [...cols, c.key]
                                      : cols.filter((x) => x !== c.key),
                                  )
                                }
                              />
                              <span>{c.label}</span>
                              {c.key === "name" && <LockKeyhole size={11} />}
                            </label>
                          ))}
                        </>
                      )}
                    </Dropdown>
                  </div>
                  {(filterCount > 0 || q) && (
                    <div className="active-filters">
                      <span>Filtered by</span>
                      {q && (
                        <button
                          onClick={() => {
                            setSearch("");
                            setPage(1);
                          }}
                        >
                          “{q}”<X size={11} />
                        </button>
                      )}
                      {Object.entries(filters)
                        .filter(([, v]) => v)
                        .map(([k, v]) => (
                          <button key={k} onClick={() => setFilter(k, "")}>
                            {v}
                            <X size={11} />
                          </button>
                        ))}
                      <button className="clear-all" onClick={clearFilters}>
                        Clear all
                      </button>
                    </div>
                  )}
                  <div className="table-scroll" aria-busy={loading}>
                    <table
                      className="officers-table"
                      aria-label="Officer directory"
                    >
                      <thead>
                        <tr>
                          <th className="select-cell">
                            <input
                              type="checkbox"
                              aria-label="Select all officers on this page"
                              checked={allSelected}
                              onChange={() =>
                                setSelected(
                                  allSelected
                                    ? new Set()
                                    : new Set(data.officers.map((o) => o.id)),
                                )
                              }
                              disabled={!data.officers.length}
                            />
                          </th>
                          {shownColumns.map((c) => (
                            <th
                              key={c.key}
                              className={cx(
                                `col-${c.key}`,
                                sort.column === c.key && "is-sorted",
                              )}
                              aria-sort={
                                sort.column === c.key
                                  ? sort.direction === "asc"
                                    ? "ascending"
                                    : "descending"
                                  : "none"
                              }
                            >
                              <button
                                onClick={() => toggleSort(c.key)}
                                aria-label={`Sort by ${c.label}`}
                              >
                                {c.label}
                                {sort.column === c.key ? (
                                  sort.direction === "asc" ? (
                                    <ArrowUp size={13} />
                                  ) : (
                                    <ArrowDown size={13} />
                                  )
                                ) : (
                                  <ArrowUpDown size={12} />
                                )}
                              </button>
                            </th>
                          ))}
                          <th className="action-cell">
                            <span className="sr-only">Actions</span>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {loading && !data.officers.length && !loadError
                          ? Array.from({ length: 8 }, (_, i) => (
                              <tr className="skeleton-row" key={i}>
                                <td className="select-cell">
                                  <span className="skeleton skeleton-checkbox" />
                                </td>
                                {shownColumns.map((c) => (
                                  <td key={c.key}>
                                    <span
                                      className={cx(
                                        "skeleton",
                                        c.key === "name"
                                          ? "skeleton-name"
                                          : "skeleton-line",
                                      )}
                                    />
                                  </td>
                                ))}
                                <td />
                              </tr>
                            ))
                          : data.officers.map((o, i) => (
                              <tr
                                key={o.id}
                                className={cx(
                                  "officer-row",
                                  selected.has(o.id) && "row-selected",
                                )}
                                style={{ "--row-delay": `${i * 25}ms` }}
                              >
                                <td className="select-cell">
                                  <input
                                    type="checkbox"
                                    aria-label={`Select ${o.name}`}
                                    checked={selected.has(o.id)}
                                    onChange={() => toggleSelected(o.id)}
                                  />
                                </td>
                                {shownColumns.map((c) => (
                                  <td key={c.key} className={`col-${c.key}`}>
                                    {c.key === "name" ? (
                                      <button
                                        className="officer-name"
                                        onClick={() => openProfile(o)}
                                      >
                                        <Avatar name={o.name} />
                                        <span>
                                          <strong>{o.name}</strong>
                                          <small>
                                            {o.email || "No email provided"}
                                          </small>
                                        </span>
                                      </button>
                                    ) : c.key === "badge_id" ? (
                                      <span className="badge-number">
                                        {o.badge_id}
                                      </span>
                                    ) : c.key === "status" ? (
                                      <StatusPill status={o.status} />
                                    ) : (
                                      <span
                                        className={cx(
                                          c.key === "rank"
                                            ? "rank-text"
                                            : "assignment-text",
                                        )}
                                      >
                                        {o[c.key]}
                                      </span>
                                    )}
                                  </td>
                                ))}
                                <td className="action-cell">
                                  <Dropdown
                                    label={`Actions for ${o.name}`}
                                    className="row-menu-trigger"
                                    trigger={<MoreHorizontal size={19} />}
                                  >
                                    {(close) => (
                                      <>
                                        <button
                                          className="menu-item"
                                          onClick={() => {
                                            close();
                                            openProfile(o);
                                          }}
                                        >
                                          <UserRound size={16} />
                                          View profile
                                        </button>
                                        <button
                                          className="menu-item"
                                          onClick={() => {
                                            close();
                                            openEdit(o);
                                          }}
                                        >
                                          <Pencil size={15} />
                                          Edit details
                                          {!auth.authenticated && (
                                            <LockKeyhole
                                              size={11}
                                              className="menu-end-icon"
                                            />
                                          )}
                                        </button>
                                        <div className="menu-divider" />
                                        <button
                                          className="menu-item menu-danger"
                                          onClick={() => {
                                            close();
                                            openDelete([o]);
                                          }}
                                        >
                                          <Trash2 size={15} />
                                          Remove officer
                                          {!auth.authenticated && (
                                            <LockKeyhole
                                              size={11}
                                              className="menu-end-icon"
                                            />
                                          )}
                                        </button>
                                      </>
                                    )}
                                  </Dropdown>
                                </td>
                              </tr>
                            ))}
                      </tbody>
                    </table>
                    {!loading && !data.officers.length && (
                      <div className="empty-state">
                        <div>
                          <Search size={24} />
                        </div>
                        <h2>
                          {q || filterCount
                            ? "No one here by that name."
                            : "Your team starts here."}
                        </h2>
                        <p>
                          {q || filterCount
                            ? "Try a different search or give your filters a little room."
                            : "Add your first officer to bring your directory to life."}
                        </p>
                        <Button
                          onClick={q || filterCount ? clearFilters : openAdd}
                          icon={q || filterCount ? X : Plus}
                        >
                          {q || filterCount
                            ? "Clear search & filters"
                            : "Add your first officer"}
                        </Button>
                      </div>
                    )}
                  </div>
                  <div className="table-footer">
                    <span>
                      {loading && data.officers.length ? (
                        "Updating…"
                      ) : (
                        <>
                          Showing{" "}
                          <strong>
                            {data.total
                              ? (data.page - 1) * data.page_size + 1
                              : 0}
                            –{Math.min(data.page * data.page_size, data.total)}
                          </strong>{" "}
                          of <strong>{data.total}</strong> officers
                        </>
                      )}
                    </span>
                    <div className="table-footer-right">
                      <select
                        aria-label="Officers per page"
                        value={pageSize}
                        onChange={(e) => {
                          setPageSize(Number(e.target.value));
                          setPage(1);
                        }}
                      >
                        <option value={8}>8 per page</option>
                        <option value={12}>12 per page</option>
                        <option value={24}>24 per page</option>
                        <option value={48}>48 per page</option>
                      </select>
                      <div className="pagination">
                        <button
                          aria-label="Previous page"
                          disabled={data.page <= 1 || loading}
                          onClick={() => setPage((p) => p - 1)}
                        >
                          <ChevronLeft size={15} />
                        </button>
                        {displayedPages.map((n, i) => (
                          <React.Fragment key={n}>
                            {i > 0 && n - displayedPages[i - 1] > 1 && (
                              <span className="pagination-ellipsis">…</span>
                            )}
                            <button
                              className={cx(data.page === n && "current-page")}
                              aria-label={`Page ${n}`}
                              aria-current={
                                data.page === n ? "page" : undefined
                              }
                              onClick={() => setPage(n)}
                              disabled={loading}
                            >
                              {n}
                            </button>
                          </React.Fragment>
                        ))}
                        <button
                          aria-label="Next page"
                          disabled={data.page >= data.pages || loading}
                          onClick={() => setPage((p) => p + 1)}
                        >
                          <ChevronRight size={15} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="directory-bottom">
                  <span>
                    <ShieldCheck size={14} />A little structure. A lot of peace
                    of mind.
                  </span>
                  {stats?.sample_count > 0 ? (
                    <button onClick={() => setModal("samples")}>
                      <span className="sample-indicator" />
                      {stats.sample_count} fictional sample records
                      <CircleHelp size={12} />
                    </button>
                  ) : (
                    <span>
                      <Database size={12} />
                      Stored securely in your workspace
                    </span>
                  )}
                </div>
              </motion.section>
            )}
            {view === "overview" && (
              <Overview
                stats={stats}
                onNavigate={navigate}
                onStatus={setStatus}
                onAdd={openAdd}
                onExport={exportFile}
              />
            )}
            {view === "exports" && (
              <ExportPage
                stats={stats}
                filteredTotal={data.total}
                filtersActive={!!q || filterCount > 0}
                onExport={exportFile}
                exporting={exporting}
              />
            )}
            {view === "activity" && <ActivityPage revision={revision} />}
            <footer className="page-footer">
              <span>Built for your people.</span>
              <Logo compact />
              <span>Made simple.</span>
            </footer>
          </main>
        </div>
      </div>
      <AnimatePresence>
        {selected.size > 0 && directoryView && (
          <motion.div
            className="selection-bar"
            initial={{ opacity: 0, y: 32, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 22 }}
          >
            <span className="selection-number">{selected.size}</span>
            <strong>
              {selected.size === 1 ? "officer" : "officers"} selected
            </strong>
            <button
              className="selection-clear"
              onClick={() => setSelected(new Set())}
            >
              Clear
            </button>
            <span className="selection-divider" />
            <Button
              variant="danger"
              icon={Trash2}
              onClick={() =>
                openDelete(data.officers.filter((o) => selected.has(o.id)))
              }
            >
              Remove selected{!auth.authenticated && <LockKeyhole size={12} />}
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence mode="wait">
        {modal === "auth" && (
          <AuthDialog
            key="auth"
            configured={auth.configured}
            onClose={closeModal}
            onSuccess={authSuccess}
          />
        )}
        {modal === "password" && (
          <AuthDialog
            key="password"
            configured
            changePassword
            onClose={closeModal}
            onSuccess={authSuccess}
          />
        )}
        {modal === "officer" && (
          <OfficerForm
            key={officer?.id || "new-officer"}
            officer={officer}
            assignments={stats?.assignments || []}
            onClose={closeModal}
            onSave={(saved, added) => {
              setModal(null);
              setSelected(new Set());
              setRevision((r) => r + 1);
              notify(
                `${saved.name} ${added ? "added to the team" : "updated"}. All saved.`,
              );
            }}
          />
        )}
        {modal === "profile" && officer && (
          <OfficerProfile
            key="profile"
            officer={officer}
            authenticated={auth.authenticated}
            onClose={closeModal}
            onEdit={openEdit}
            onDelete={openDelete}
          />
        )}
        {modal === "delete" && (
          <DeleteDialog
            key="delete"
            officers={deleting}
            onClose={closeModal}
            onDeleted={(count) => {
              setModal(null);
              setSelected(new Set());
              setRevision((r) => r + 1);
              notify(
                `${count === 1 ? "Officer" : `${count} officers`} removed from the directory.`,
              );
            }}
          />
        )}
        {modal === "help" && (
          <Dialog
            label="A little help"
            key="help"
            onClose={closeModal}
            className="help-dialog"
          >
            <button
              className="dialog-close"
              onClick={closeModal}
              aria-label="Close help"
            >
              <X size={18} />
            </button>
            <div className="auth-symbol">
              <Sparkles size={26} />
            </div>
            <h2>A little clarity.</h2>
            <p>
              Roster keeps your officer directory simple, organized, and always
              up to date.
            </p>
            <div className="help-steps">
              <div>
                <Search size={19} />
                <span>
                  <strong>Find your people</strong>Search by name, badge, rank,
                  unit, email, or phone. Use ⌘K or Ctrl+K to jump to search.
                </span>
              </div>
              <div>
                <LockKeyhole size={19} />
                <span>
                  <strong>Make changes safely</strong>Click Admin access to set
                  your own password on the first visit. Only admins can add,
                  edit, or remove officers.
                </span>
              </div>
              <div>
                <ArrowUpDown size={19} />
                <span>
                  <strong>Your directory, your view</strong>Click a column
                  heading to sort. Filter by duty status, rank, or assignment
                  and choose visible columns.
                </span>
              </div>
              <div>
                <FileSpreadsheet size={19} />
                <span>
                  <strong>Take it with you</strong>Download CSV or Excel files.
                  Exports include all matching records, not just the page you’re
                  viewing.
                </span>
              </div>
              <div>
                <Database size={19} />
                <span>
                  <strong>Saved for the long run</strong>Records are stored in a
                  real SQLite database and remain after refreshing or restarting
                  the server.
                </span>
              </div>
            </div>
            <Button
              variant="primary"
              className="full-width"
              onClick={closeModal}
            >
              Got it
              <Check size={15} />
            </Button>
          </Dialog>
        )}
        {modal === "samples" && (
          <Dialog
            label="About sample records"
            key="samples"
            onClose={closeModal}
            className="help-dialog"
          >
            <button
              className="dialog-close"
              onClick={closeModal}
              aria-label="Close sample information"
            >
              <X size={18} />
            </button>
            <div className="auth-symbol">
              <UsersRound size={26} />
            </div>
            <h2>A head start, not real data.</h2>
            <p>
              Your workspace includes 24 fictional officer records so you can
              explore search, sorting, and exports right away. Names and contact
              information are for demonstration only.
            </p>
            <div className="sample-info">
              <ShieldCheck size={20} />
              <span>
                Ready to make it your own? Unlock admin access, select the
                sample records, and remove them. Then add your real team.
                Changes are permanent and saved automatically.
              </span>
            </div>
            <Button
              variant="primary"
              className="full-width"
              onClick={closeModal}
            >
              Sounds good
              <Check size={15} />
            </Button>
          </Dialog>
        )}
      </AnimatePresence>
      <div className="toast-stack" aria-live="polite">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              className={cx("toast", t.type === "error" && "toast-error")}
              initial={{ opacity: 0, y: 20, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, x: 30 }}
            >
              <span>
                {t.type === "error" ? <X size={16} /> : <Check size={16} />}
              </span>
              <p>{t.message}</p>
              <button
                aria-label="Dismiss notification"
                onClick={() =>
                  setToasts((items) => items.filter((x) => x.id !== t.id))
                }
              >
                <X size={14} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </MotionConfig>
  );
}
