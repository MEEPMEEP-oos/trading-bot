# Roster — Officer directory

A spreadsheet-style officer directory with a React interface, a Flask/Waitress API, and persistent SQLite storage. Includes production Docker packaging, a Render deployment blueprint, and private backup/password-recovery tools. No external API keys or separate cloud database account are needed.

## Deploy it

**Read [DEPLOY.md](DEPLOY.md) for the step-by-step Render or Docker instructions.**

- **Render:** put this project's contents at your GitHub repository root, create a Render Blueprint, and enter your own `ROSTER_ADMIN_PASSWORD` when prompted. The provided paid service has a 1 GB persistent disk.
- **Docker:** copy `.env.example` to `.env`, set a password, and run `docker compose up --build -d`. Open http://localhost:3000.
- Production starts with an **empty directory** and requires private admin configuration **before** listening. A public visitor cannot claim administrator access.
- This is a full-stack, single-instance application, not a static-only or serverless deployment. Keep the database on a persistent disk/volume.

The source archive does not contain the live preview database or any real administrator credentials. Follow the private migration instructions in DEPLOY.md if you want to move an existing workspace.

## Start using it

Open the website, then click **Admin access** or **Manage officers**.

- **Production:** enter the password you configured in the hosting settings. There is no preset password.
- **Local preview/development:** on first use, choose your own password (12–128 characters). New development databases include 24 clearly labeled fictional sample records.
- Signing in unlocks adding, editing, and removing officers. Protection is enforced by the server.
- **Production is private by default:** viewing, searching, profiles, activity, and CSV/Excel exports all require signing in (`ROSTER_PUBLIC_VIEW=false`). Local development defaults to public viewing; set `ROSTER_PUBLIC_VIEW=true` in production only if you want a public directory.
- Change the password in the management panel. Password changes and officer records survive updates and restarts. For a forgotten password, use the private `server.manage set-password` command; there is no email recovery or public reset endpoint.

**Privacy:** with `ROSTER_PUBLIC_VIEW=true` the admin password protects edits, not viewing. Use approved work information only. Database files and backups are not application-encrypted.

## Features

- Nine fields: name, unique badge number, rank, assignment/unit, duty status, email, phone, joined date, and notes.
- Protected create/edit/delete and bulk removal, with confirmation and optimistic stale-edit protection.
- Search by name, badge, rank, assignment, email, or phone; **⌘K / Ctrl+K** focuses search.
- Click sortable column headings for ascending/descending order.
- Status, rank, and assignment filters; optional column visibility; pagination and page size.
- Search/filter-aware CSV and genuine `.xlsx` Excel exports covering **all matching records**, not just the displayed page.
- Styled/filterable workbooks, frozen headers, sensible widths, and spreadsheet formula-injection protection.
- Officer profile drawers, overview, activity history, password changes, and sign-out.
- Apple-inspired spring transitions, translucent panels, hover states, focus management, and reduced-motion support.
- Responsive mobile layout with an independently scrollable table.
- Local fonts/assets; no runtime CDN dependencies.

## Run locally without Docker

Requirements: **Python 3.10+** (3.13 tested) and **Node 20.19+ or 22.12+** (production builds use Node 22).

```bash
cd roster
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
npm ci
npm run build
npm start
```

Open **http://localhost:3000**. Waitress binds to `0.0.0.0`; Flask's development server is not used. The downloadable package includes the built `web/` folder, so Python alone can serve it if you do not need to rebuild:

```bash
.venv/bin/python -m server.app
```

### Frontend development

Two terminals:

```bash
# API
PORT=3001 .venv/bin/python -m server.app

# React/Vite, port 3000; relative /api requests are proxied to the API
npm run dev
```

For an HTTPS embedded workspace preview:

```bash
COOKIE_SECURE=true COOKIE_SAMESITE=None COOKIE_PARTITIONED=true npm start
```

These cookie settings are for cross-site embedding, not normal standalone hosting. Production additionally restricts trusted iframe origins; see DEPLOY.md.

## Storage and security

Local data is in **`data/roster.sqlite3`**, or the path supplied by `ROSTER_DB`. SQLite uses WAL journaling. Samples are inserted only when initializing a new development database; deleted samples do not reappear. Deployment uses an attached volume/disk, not ephemeral image storage.

Passwords use salted scrypt hashing. Eight-hour sessions use random tokens stored as hashes, with HttpOnly cookies. Production defaults to Secure/SameSite=Lax cookies and adds security headers/CSP. Mutations require JSON/custom headers, enforce authorization/origin checks, validate records, prevent duplicate badges, and detect conflicting edits. Sign-in and password-change attempts are limited to 10 failures per 15 minutes per IP, and all API traffic has per-IP rate limits (600 requests/min, 60 writes/min, 20 exports/min). Responses include CSP, HSTS, X-Frame-Options, COOP/CORP and Permissions-Policy headers; no CORS headers are sent, so other websites cannot read the API; passwords must be 12+ characters and are stored as salted scrypt hashes. There is one shared administrator role—not individual identities, MFA, or an enterprise identity system.

Backup while running:

```bash
.venv/bin/python -m server.manage backup /private/location/roster-backup.sqlite3
```

The consistent SQLite backup includes data, settings, hashes, and history. Keep it private. Restore always uses a new filename and revokes previous sessions. Never delete your live database/volume to update the application. Full maintenance and recovery instructions are in **DEPLOY.md**.

## Verification

```bash
.venv/bin/pip install -r requirements-dev.txt
npx playwright install --with-deps chromium
npm test
```

Tests use independent temporary databases: authorization, setup/sign-in/out, CRUD, validation, all sortable fields, filters/pagination, CSV/Excel content, formula safety, conflicts, bulk deletion, sessions, password changes, rate limits, embedded cookies, production bootstrap, persistence, backup/restore/reset, container configuration, and Render schema validation. See **VERIFICATION.md** for the recorded results and limitations.

### End-to-end browser tests

**Destructive—never target a real directory.** Use a fresh isolated development database:

```bash
# Terminal 1: stop this server before removing ONLY its test database on reruns.
PORT=3002 ROSTER_ENV=development ROSTER_DB=/tmp/roster-browser-tests.sqlite3 \
  COOKIE_SECURE=true COOKIE_SAMESITE=None COOKIE_PARTITIONED=true \
  .venv/bin/python -m server.app

# Terminal 2
npm run test:browser
```

The suite covers real downloads, desktop/mobile flows, CRUD, login/password changes, bulk deletion, refresh persistence, and editing inside a cross-site iframe.

Read-only accessibility checks against a running preview:

```bash
npm run test:a11y
```

`tests/production-browser.mjs` additionally checks a **fresh isolated empty production workspace**, deployment-configured login, protected CRUD, Excel, mobile layout, and CSP/browser errors. It requires `PRODUCTION_TEST_PASSWORD` and optionally `PRODUCTION_TEST_URL` (default http://127.0.0.1:3080). For plain HTTP testing only, launch that isolated production server with `COOKIE_SECURE=false`. `tests/deployment_smoke.py` checks persistence across a real server/container restart; run its first phase on an empty test database, restart, then run `--after-restart`.

The included GitHub Actions workflow runs the main tests and builds/smoke-tests the actual Docker image with a disposable persistent volume.

## Project structure

```text
Dockerfile             Multi-stage frontend/backend production image
compose.yaml           Local/VPS deployment with a named persistent volume
render.yaml            Render Blueprint with a persistent disk
.env.example           Public template; copy privately to .env
DEPLOY.md              Hosting, HTTPS, backup, migration, and password recovery
src/                   React interface and styles
server/app.py          Flask API, SQLite storage, auth, exports, Waitress
server/config.py       Validated development/production environment settings
server/launch.py       Container volume preparation and privilege drop
server/manage.py       Private backup, restore, and password reset CLI
public/                Local font/license and favicon
web/                   Built frontend ready to serve
requirements*.txt      Runtime pins and test dependencies
.github/workflows/     API/browser checks and actual Docker smoke-test CI
tests/                 API, deployment, browser, accessibility, smoke checks
data/                  Local persistent database (not in the source archive)
```
