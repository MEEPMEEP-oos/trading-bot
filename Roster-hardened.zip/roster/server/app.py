"""Roster: a persistent, password-protected officer directory."""
from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
import secrets
import sqlite3
import threading
import time
import uuid
from collections import deque
from datetime import datetime, timezone
from contextlib import contextmanager
from functools import wraps
from pathlib import Path

from flask import Flask, jsonify, request, send_file, send_from_directory
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.table import Table, TableStyleInfo
from werkzeug.security import check_password_hash, generate_password_hash

if __package__:
    from .config import runtime_config
else:
    from config import runtime_config

ROOT = Path(__file__).resolve().parent.parent
RANKS = ["Officer", "Senior Officer", "Corporal", "Sergeant", "Lieutenant", "Captain"]
STATUSES = ["On duty", "Off duty", "On leave"]
FIELDS = ["name", "badge_id", "rank", "assignment", "status", "email", "phone", "joined_date", "notes"]
EXPORT_HEADERS = ["Name", "Badge number", "Rank", "Assignment", "Status", "Email", "Phone", "Joined date", "Notes"]
SESSION_SECONDS = 8 * 60 * 60
MAX_SESSIONS = 25
MIN_PASSWORD = 12
MAX_PASSWORD = 128
COMMON_PASSWORDS = {
    "password1234", "123456789012", "qwertyuiop12", "administrator", "adminadmin12",
    "passwordpassword", "letmein12345", "welcome12345", "rosterroster", "roster123456",
    "changeme1234", "iloveyou1234", "password123!", "password1234!",
}
# Rate limits (per client IP): requests allowed per rolling window in seconds.
RATE_LIMITS = {"api": (600, 60), "write": (60, 60), "export": (20, 60)}
EMAIL_PATTERN = re.compile(r"[A-Za-z0-9.!#$%&'*+/=^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)+")
PHONE_PATTERN = re.compile(r"[0-9+().#*xX\s-]*")
CONTROL_CHARACTERS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def now():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def valid_password(password):
    """12-128 characters, not blank, not a trivially guessable value."""
    if not isinstance(password, str) or not MIN_PASSWORD <= len(password) <= MAX_PASSWORD or password.isspace():
        return False
    if password.lower() in COMMON_PASSWORDS or len(set(password)) < 5:
        return False
    return True


PASSWORD_RULE = f"Use a password between {MIN_PASSWORD} and {MAX_PASSWORD} characters that is not a common or repetitive value."


def create_app(database_path=None, seed=None):
    app = Flask(__name__, static_folder=None)
    app.config.update(runtime_config(ROOT, database_path))
    if seed is None:
        seed = app.config["SEED_DEMO"]
    if app.config["PRODUCTION"] and not (ROOT / "web" / "index.html").is_file():
        raise RuntimeError("Build the frontend with npm ci && npm run build before starting production.")
    Path(app.config["DATABASE"]).parent.mkdir(parents=True, exist_ok=True)
    attempts = {}
    hits = {}
    guard = threading.Lock()

    def client_ip():
        return request.remote_addr or "unknown"

    def rate_limited(bucket):
        """Rolling-window limiter per client IP. Returns seconds to wait, or 0."""
        limit, window = RATE_LIMITS[bucket]
        moment = time.monotonic()
        with guard:
            queue = hits.setdefault((bucket, client_ip()), deque())
            while queue and queue[0] <= moment - window:
                queue.popleft()
            if len(queue) >= limit:
                return int(window - (moment - queue[0])) + 1
            queue.append(moment)
            if len(hits) > 5000:  # bound memory under address-spraying
                for key in [k for k, v in hits.items() if not v or v[-1] <= moment - 120]:
                    del hits[key]
        return 0

    def login_blocked(ip):
        with guard:
            record = attempts.get(ip)
            if record and time.time() - record["started"] > 15 * 60:
                attempts.pop(ip, None)
                return False
            return bool(record and record["count"] >= 10)

    def login_failed(ip):
        with guard:
            record = attempts.get(ip)
            if not record or time.time() - record["started"] > 15 * 60:
                record = {"count": 0, "started": time.time()}
            record["count"] += 1
            attempts[ip] = record
            if len(attempts) > 5000:
                for key in [k for k, v in attempts.items() if time.time() - v["started"] > 15 * 60]:
                    del attempts[key]

    def json_body():
        data = request.get_json(silent=True)
        return data if isinstance(data, dict) else {}

    @contextmanager
    def connect():
        db = sqlite3.connect(app.config["DATABASE"], timeout=15)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA journal_mode=WAL")
        try:
            with db:
                yield db
        finally:
            db.close()

    def meta(db, key):
        row = db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row[0] if row else None

    def log(db, action, message, officer_id=None, details=None, actor="Administrator"):
        db.execute(
            "INSERT INTO activity(id, action, message, officer_id, details, actor, created_at) VALUES(?,?,?,?,?,?,?)",
            (str(uuid.uuid4()), action, message, officer_id, json.dumps(details or {}), actor, now()),
        )

    with connect() as db:
        db.executescript("""
            CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS officers (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                badge_id TEXT NOT NULL COLLATE NOCASE UNIQUE,
                rank TEXT NOT NULL,
                assignment TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('On duty','Off duty','On leave')),
                email TEXT NOT NULL DEFAULT '',
                phone TEXT NOT NULL DEFAULT '',
                joined_date TEXT NOT NULL DEFAULT '',
                notes TEXT NOT NULL DEFAULT '',
                is_demo INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS officers_name_idx ON officers(name COLLATE NOCASE);
            CREATE INDEX IF NOT EXISTS officers_status_idx ON officers(status);
            CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, expires_at INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS activity (
                id TEXT PRIMARY KEY, action TEXT NOT NULL, message TEXT NOT NULL,
                officer_id TEXT, details TEXT NOT NULL, actor TEXT NOT NULL, created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS activity_date_idx ON activity(created_at DESC);
        """)
        if not meta(db, "initialized"):
            if seed:
                names = [
                    ("Aiden Brooks", "Sergeant", "Patrol Operations"),
                    ("Amelia Carter", "Officer", "Community Policing"),
                    ("Benjamin Cole", "Senior Officer", "Traffic Division"),
                    ("Charlotte Davis", "Lieutenant", "Investigations"),
                    ("Daniel Edwards", "Officer", "Patrol Operations"),
                    ("Elena Foster", "Corporal", "Special Operations"),
                    ("Ethan Grant", "Officer", "Patrol Operations"),
                    ("Grace Hayes", "Sergeant", "Community Policing"),
                    ("Henry James", "Senior Officer", "Traffic Division"),
                    ("Isabella King", "Captain", "Administration"),
                    ("Jacob Lewis", "Officer", "Patrol Operations"),
                    ("Jasmine Mitchell", "Corporal", "Investigations"),
                    ("Leo Morgan", "Officer", "Special Operations"),
                    ("Liam Nelson", "Senior Officer", "Patrol Operations"),
                    ("Maya Parker", "Officer", "Community Policing"),
                    ("Noah Reed", "Sergeant", "Traffic Division"),
                    ("Olivia Scott", "Lieutenant", "Investigations"),
                    ("Owen Taylor", "Officer", "Patrol Operations"),
                    ("Sofia Turner", "Corporal", "Special Operations"),
                    ("Sophie Walker", "Officer", "Community Policing"),
                    ("William Ward", "Senior Officer", "Traffic Division"),
                    ("Zoe Williams", "Officer", "Investigations"),
                    ("Lucas Wright", "Officer", "Patrol Operations"),
                    ("Ava Bennett", "Sergeant", "Administration"),
                ]
                for i, (name, rank, assignment) in enumerate(names):
                    status = "On duty" if i < 16 else "Off duty" if i < 22 else "On leave"
                    stamp = now()
                    db.execute(
                        "INSERT INTO officers VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (str(uuid.uuid4()), name, f"OF-{1042 + i}", rank, assignment, status,
                         name.lower().replace(" ", ".") + "@example.com", "",
                         f"{2017 + i % 8}-{1 + i % 12:02d}-{5 + i % 20:02d}", "Fictional sample record. Replace with your own officer details.", 1, stamp, stamp),
                    )
                log(db, "workspace", "Your workspace is ready. 24 fictional sample officers have been added.", actor="System")
            db.execute("INSERT INTO settings(key,value) VALUES('initialized','1')")
            if not seed:
                log(db, "workspace", "Your officer workspace is ready.", actor="System")
        # Bootstrap privately before opening a production listener. An existing
        # password is NEVER replaced on redeploy, including one changed in the UI.
        if not meta(db, "admin_password"):
            bootstrap_password = os.environ.get("ROSTER_ADMIN_PASSWORD")
            if bootstrap_password is not None:
                if not valid_password(bootstrap_password):
                    raise RuntimeError(f"ROSTER_ADMIN_PASSWORD must contain {MIN_PASSWORD}–{MAX_PASSWORD} characters, cannot be blank, and cannot be a common or repetitive value.")
                db.execute("INSERT INTO settings VALUES('admin_password',?)", (generate_password_hash(bootstrap_password),))
                log(db, "security", "Administrator access was initialized from deployment configuration.", actor="System")
            elif app.config["PRODUCTION"]:
                raise RuntimeError("Set ROSTER_ADMIN_PASSWORD before the first production start. Public password setup is disabled in production.")
    if app.config["PRODUCTION"]:
        Path(app.config["DATABASE"]).chmod(0o600)

    def current_session(db):
        token = request.cookies.get("roster_session", "")
        if not token:
            return None
        digest = hashlib.sha256(token.encode()).hexdigest()
        row = db.execute("SELECT token_hash FROM sessions WHERE token_hash=? AND expires_at>?", (digest, int(time.time()))).fetchone()
        return row[0] if row else None

    def requires_admin(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            with connect() as db:
                if not current_session(db):
                    return jsonify(error="Administrator access is required. Please sign in."), 401
            return fn(*args, **kwargs)
        return wrapped

    def requires_viewer(fn):
        """Directory data needs a session unless ROSTER_PUBLIC_VIEW is enabled."""
        @wraps(fn)
        def wrapped(*args, **kwargs):
            if not app.config["PUBLIC_VIEW"]:
                with connect() as db:
                    if not current_session(db):
                        return jsonify(error="Please sign in to view the directory."), 401
            return fn(*args, **kwargs)
        return wrapped

    def establish_session(db):
        token = secrets.token_urlsafe(48)
        db.execute("DELETE FROM sessions WHERE expires_at<=?", (int(time.time()),))
        db.execute("INSERT INTO sessions VALUES(?,?)", (hashlib.sha256(token.encode()).hexdigest(), int(time.time()) + SESSION_SECONDS))
        db.execute("DELETE FROM sessions WHERE token_hash NOT IN (SELECT token_hash FROM sessions ORDER BY expires_at DESC LIMIT ?)", (MAX_SESSIONS,))
        response = jsonify(authenticated=True, configured=True)
        response.set_cookie("roster_session", token, max_age=SESSION_SECONDS, httponly=True, secure=app.config["COOKIE_SECURE"], samesite=app.config["COOKIE_SAMESITE"], partitioned=app.config["COOKIE_PARTITIONED"], path="/")
        return response

    @app.before_request
    def protect_requests():
        if not request.path.startswith("/api/"):
            return None
        buckets = ["api"]
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            buckets.append("write")
        if request.path.startswith("/api/export/"):
            buckets.append("export")
        for bucket in buckets:
            wait = rate_limited(bucket)
            if wait:
                response = jsonify(error="Too many requests. Please slow down and try again shortly.")
                response.status_code = 429
                response.headers["Retry-After"] = str(wait)
                return response
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            if request.headers.get("X-Roster-Request") != "1":
                return jsonify(error="Invalid request. Refresh the page and try again."), 403
            origin = request.headers.get("Origin")
            if origin:
                from urllib.parse import urlparse
                if urlparse(origin).netloc != request.host:
                    return jsonify(error="Cross-origin requests are not permitted."), 403
            if request.method != "DELETE" and not request.is_json:
                return jsonify(error="A JSON request body is required."), 415

    @app.after_request
    def security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["X-Permitted-Cross-Domain-Policies"] = "none"
        if app.config["PRODUCTION"]:
            response.headers["Content-Security-Policy"] = (
                "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
                "font-src 'self' data:; img-src 'self' data:; connect-src 'self'; "
                "object-src 'none'; base-uri 'self'; form-action 'self'; "
                f"frame-ancestors {app.config['FRAME_ANCESTORS']}"
            )
            response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()"
            if app.config["FRAME_ANCESTORS"] == "'self'":
                # Legacy browsers ignore frame-ancestors; only set when no cross-site embedding is configured.
                response.headers["X-Frame-Options"] = "SAMEORIGIN"
                response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
                response.headers["Cross-Origin-Resource-Policy"] = "same-origin"
            if app.config["COOKIE_SECURE"]:
                response.headers["Strict-Transport-Security"] = "max-age=31536000"
                response.headers["Content-Security-Policy"] += "; upgrade-insecure-requests"
        if request.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.errorhandler(413)
    def too_large(_):
        return jsonify(error="This request is too large."), 413

    @app.errorhandler(400)
    def bad_request(_):
        return jsonify(error="The request could not be read. Check your input and try again."), 400

    @app.errorhandler(404)
    def not_found(_):
        return jsonify(error="Not found."), 404

    @app.errorhandler(405)
    def method_not_allowed(_):
        return jsonify(error="That method is not allowed here."), 405

    @app.errorhandler(Exception)
    def unexpected(error):
        from werkzeug.exceptions import HTTPException
        if isinstance(error, HTTPException):
            return jsonify(error=error.name), error.code
        app.logger.exception("Unhandled error")  # stays in server logs, never in the response
        return jsonify(error="Something went wrong on the server. Please try again."), 500

    @app.get("/api/health")
    def health():
        with connect() as db:
            db.execute("SELECT 1").fetchone()
        return jsonify(status="ok", database="connected", storage="SQLite", persistent=True)

    @app.get("/api/auth/status")
    def auth_status():
        with connect() as db:
            return jsonify(authenticated=bool(current_session(db)), configured=bool(meta(db, "admin_password")), public_view=app.config["PUBLIC_VIEW"])

    def password_valid(password):
        return valid_password(password)

    @app.post("/api/auth/setup")
    def setup():
        if app.config["PRODUCTION"]:
            return jsonify(error="Administrator setup is managed by your deployment configuration."), 403
        payload = json_body()
        password = payload.get("password")
        if not password_valid(password):
            return jsonify(error=PASSWORD_RULE), 400
        with connect() as db:
            db.execute("BEGIN IMMEDIATE")
            if meta(db, "admin_password"):
                return jsonify(error="An administrator password already exists. Sign in instead."), 409
            db.execute("INSERT INTO settings VALUES('admin_password',?)", (generate_password_hash(password),))
            log(db, "security", "Administrator access was set up.")
            return establish_session(db)

    @app.post("/api/auth/login")
    def login():
        payload = json_body()
        password = payload.get("password", "")
        if not isinstance(password, str) or len(password) > MAX_PASSWORD:
            return jsonify(error="Incorrect password. Please try again."), 401
        ip = client_ip()
        if login_blocked(ip):
            return jsonify(error="Too many sign-in attempts. Try again in 15 minutes."), 429
        with connect() as db:
            saved = meta(db, "admin_password")
            if not saved:
                return jsonify(error="Set up an administrator password first."), 409
            if not check_password_hash(saved, password):
                login_failed(ip)
                return jsonify(error="Incorrect password. Please try again."), 401
            with guard:
                attempts.pop(ip, None)
            return establish_session(db)

    @app.post("/api/auth/logout")
    def logout():
        with connect() as db:
            session = current_session(db)
            if session:
                db.execute("DELETE FROM sessions WHERE token_hash=?", (session,))
        response = jsonify(authenticated=False)
        response.delete_cookie("roster_session", path="/", secure=app.config["COOKIE_SECURE"], samesite=app.config["COOKIE_SAMESITE"], partitioned=app.config["COOKIE_PARTITIONED"])
        return response

    @app.post("/api/auth/password")
    @requires_admin
    def change_password():
        payload = json_body()
        new_password = payload.get("new_password")
        current_password = payload.get("current_password", "")
        if not isinstance(current_password, str) or len(current_password) > MAX_PASSWORD:
            return jsonify(error="Enter your current password."), 400
        if not password_valid(new_password):
            return jsonify(error=PASSWORD_RULE), 400
        ip = client_ip()
        if login_blocked(ip):
            return jsonify(error="Too many attempts. Try again in 15 minutes."), 429
        with connect() as db:
            if not check_password_hash(meta(db, "admin_password"), current_password):
                login_failed(ip)
                return jsonify(error="Your current password is incorrect."), 401
            db.execute("UPDATE settings SET value=? WHERE key='admin_password'", (generate_password_hash(new_password),))
            db.execute("DELETE FROM sessions")
            log(db, "security", "The administrator password was changed.")
            return establish_session(db)

    def query_parts():
        q = request.args.get("q", "").strip()[:200]
        status = request.args.get("status", "")
        rank = request.args.get("rank", "")
        assignment = request.args.get("assignment", "")
        sort = request.args.get("sort", "name")
        direction = request.args.get("direction", "asc").lower()
        if sort not in FIELDS + ["created_at", "updated_at"]:
            raise ValueError("Unknown sorting column.")
        if direction not in ["asc", "desc"]:
            raise ValueError("Unknown sorting direction.")
        if status and status not in STATUSES:
            raise ValueError("Unknown officer status.")
        clauses, params = [], []
        if q:
            escaped = q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            clauses.append("(" + " OR ".join(f"{f} LIKE ? ESCAPE '\\'" for f in ["name", "badge_id", "rank", "assignment", "email", "phone"]) + ")")
            params.extend([f"%{escaped}%"] * 6)
        for field, value in [("status", status), ("rank", rank), ("assignment", assignment)]:
            if value:
                clauses.append(f"{field}=?")
                params.append(value)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        order = f" ORDER BY {sort} COLLATE NOCASE {direction.upper()}, id ASC"
        return where, params, order

    @app.get("/api/officers")
    @requires_viewer
    def officers():
        try:
            where, params, order = query_parts()
            page = max(1, int(request.args.get("page", 1)))
            page_size = max(1, min(100, int(request.args.get("page_size", 8))))
        except (ValueError, TypeError) as e:
            known = str(e) if str(e).startswith("Unknown ") else "Invalid page or page size."
            return jsonify(error=known), 400
        with connect() as db:
            total = db.execute("SELECT COUNT(*) FROM officers" + where, params).fetchone()[0]
            pages = max(1, (total + page_size - 1) // page_size)
            page = min(page, pages)
            rows = db.execute("SELECT * FROM officers" + where + order + " LIMIT ? OFFSET ?", [*params, page_size, (page - 1) * page_size]).fetchall()
        return jsonify(officers=[dict(r) for r in rows], total=total, page=page, page_size=page_size, pages=pages)

    @app.get("/api/officers/<officer_id>")
    @requires_viewer
    def get_officer(officer_id):
        with connect() as db:
            row = db.execute("SELECT * FROM officers WHERE id=?", (officer_id,)).fetchone()
        if not row:
            return jsonify(error="This officer could not be found."), 404
        return jsonify(dict(row))

    def validate_officer(payload):
        if not isinstance(payload, dict):
            raise ValueError("Provide an officer record.")
        result = {}
        limits = {"name": 100, "badge_id": 24, "assignment": 80, "email": 150, "phone": 40, "notes": 2000, "joined_date": 10, "rank": 40, "status": 20}
        for field in FIELDS:
            value = payload.get(field, "")
            if not isinstance(value, str):
                raise ValueError(f"{field.replace('_', ' ').capitalize()} must be text.")
            result[field] = value.strip()
            if len(result[field]) > limits[field]:
                raise ValueError(f"{field.replace('_', ' ').capitalize()} is too long.")
            if CONTROL_CHARACTERS.search(result[field]) or (field != "notes" and re.search(r"[\r\n]", result[field])):
                raise ValueError(f"{field.replace('_', ' ').capitalize()} contains characters that are not allowed.")
        if len(result["name"]) < 2:
            raise ValueError("Enter the officer's full name (at least 2 characters).")
        result["badge_id"] = result["badge_id"].upper()
        if not re.fullmatch(r"[A-Z0-9][A-Z0-9 ._-]{1,23}", result["badge_id"]):
            raise ValueError("Enter a badge number using 2–24 letters, numbers, spaces, dots, underscores, or hyphens.")
        if result["rank"] not in RANKS:
            raise ValueError("Select a valid rank.")
        if not result["assignment"]:
            raise ValueError("Enter an assignment or unit.")
        if result["status"] not in STATUSES:
            raise ValueError("Select a valid status.")
        if result["email"] and not EMAIL_PATTERN.fullmatch(result["email"]):
            raise ValueError("Enter a valid email address.")
        if not PHONE_PATTERN.fullmatch(result["phone"]):
            raise ValueError("Enter a valid phone number (digits, spaces, + ( ) - . # * and x only).")
        if result["joined_date"]:
            try:
                datetime.strptime(result["joined_date"], "%Y-%m-%d")
            except ValueError:
                raise ValueError("Enter a valid joined date.")
        return result

    @app.post("/api/officers")
    @requires_admin
    def add_officer():
        try:
            values = validate_officer(request.get_json(silent=True))
        except ValueError as e:
            return jsonify(error=str(e)), 400
        officer_id, stamp = str(uuid.uuid4()), now()
        try:
            with connect() as db:
                db.execute("INSERT INTO officers VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", (officer_id, *[values[f] for f in FIELDS], 0, stamp, stamp))
                log(db, "created", f"{values['name']} was added to the directory.", officer_id)
                officer = dict(db.execute("SELECT * FROM officers WHERE id=?", (officer_id,)).fetchone())
        except sqlite3.IntegrityError:
            return jsonify(error="That badge number is already in use. Choose a unique badge number."), 409
        return jsonify(officer), 201

    @app.put("/api/officers/<officer_id>")
    @requires_admin
    def edit_officer(officer_id):
        payload = request.get_json(silent=True)
        try:
            values = validate_officer(payload)
        except ValueError as e:
            return jsonify(error=str(e)), 400
        try:
            with connect() as db:
                db.execute("BEGIN IMMEDIATE")
                existing = db.execute("SELECT * FROM officers WHERE id=?", (officer_id,)).fetchone()
                if not existing:
                    return jsonify(error="This officer could not be found."), 404
                if payload.get("updated_at") and payload["updated_at"] != existing["updated_at"]:
                    return jsonify(error="This officer was updated in another window. Close this form and reopen it to load the latest details."), 409
                changed = [f for f in FIELDS if values[f] != existing[f]]
                stamp = now()
                db.execute("UPDATE officers SET " + ", ".join(f"{f}=?" for f in FIELDS) + ", updated_at=? WHERE id=?", (*[values[f] for f in FIELDS], stamp, officer_id))
                if changed:
                    log(db, "updated", f"{values['name']}'s details were updated.", officer_id, {"fields": changed})
                officer = dict(db.execute("SELECT * FROM officers WHERE id=?", (officer_id,)).fetchone())
        except sqlite3.IntegrityError:
            return jsonify(error="That badge number is already in use. Choose a unique badge number."), 409
        return jsonify(officer)

    @app.delete("/api/officers/<officer_id>")
    @requires_admin
    def delete_officer(officer_id):
        with connect() as db:
            db.execute("BEGIN IMMEDIATE")
            officer = db.execute("SELECT * FROM officers WHERE id=?", (officer_id,)).fetchone()
            if not officer:
                return jsonify(error="This officer could not be found."), 404
            db.execute("DELETE FROM officers WHERE id=?", (officer_id,))
            log(db, "deleted", f"{officer['name']} was removed from the directory.", officer_id)
        return jsonify(deleted=True)

    @app.post("/api/officers/bulk-delete")
    @requires_admin
    def bulk_delete():
        ids = json_body().get("ids")
        if not isinstance(ids, list) or not ids or len(ids) > 100 or any(not isinstance(i, str) for i in ids):
            return jsonify(error="Select between 1 and 100 officers to remove."), 400
        with connect() as db:
            db.execute("BEGIN IMMEDIATE")
            placeholders = ",".join("?" for _ in ids)
            records = db.execute(f"SELECT id, name FROM officers WHERE id IN ({placeholders})", ids).fetchall()
            db.execute(f"DELETE FROM officers WHERE id IN ({placeholders})", ids)
            if records:
                log(db, "deleted", f"{len(records)} officers were removed from the directory.", details={"names": [r['name'] for r in records]})
        return jsonify(deleted=len(records))

    @app.get("/api/stats")
    @requires_viewer
    def stats():
        with connect() as db:
            total = db.execute("SELECT COUNT(*) FROM officers").fetchone()[0]
            sample_count = db.execute("SELECT COUNT(*) FROM officers WHERE is_demo=1").fetchone()[0]
            counts = {r["status"]: r["count"] for r in db.execute("SELECT status, COUNT(*) AS count FROM officers GROUP BY status")}
            units = [dict(r) for r in db.execute("SELECT assignment AS name, COUNT(*) AS count FROM officers GROUP BY assignment ORDER BY count DESC, assignment")]
            ranks = [r[0] for r in db.execute("SELECT DISTINCT rank FROM officers ORDER BY rank")]
            recent = [dict(r) for r in db.execute("SELECT * FROM activity ORDER BY created_at DESC LIMIT 5")]
        return jsonify(total=total, on_duty=counts.get("On duty", 0), off_duty=counts.get("Off duty", 0), on_leave=counts.get("On leave", 0), assignments=units, ranks=ranks, rank_options=RANKS, sample_count=sample_count, recent_activity=recent)

    @app.get("/api/activity")
    @requires_viewer
    def activity():
        try:
            page = max(1, int(request.args.get("page", 1)))
        except ValueError:
            return jsonify(error="Invalid page."), 400
        action = request.args.get("action", "")
        where, params = (" WHERE action=?", [action]) if action else ("", [])
        with connect() as db:
            total = db.execute("SELECT COUNT(*) FROM activity" + where, params).fetchone()[0]
            pages = max(1, (total + 11) // 12)
            page = min(page, pages)
            items = [dict(r) for r in db.execute("SELECT * FROM activity" + where + " ORDER BY created_at DESC LIMIT 12 OFFSET ?", [*params, (page - 1) * 12])]
        return jsonify(items=items, total=total, page=page, pages=pages)

    @app.get("/api/export/<file_type>")
    @requires_viewer
    def export(file_type):
        if file_type not in ["csv", "xlsx"]:
            return jsonify(error="Choose CSV or Excel format."), 400
        try:
            where, params, order = query_parts()
        except ValueError as e:
            return jsonify(error=str(e)), 400
        with connect() as db:
            rows = db.execute("SELECT * FROM officers" + where + order, params).fetchall()
        filename = f"roster-officers-{datetime.now(timezone.utc).strftime('%Y-%m-%d')}.{file_type}"
        if file_type == "csv":
            output = io.StringIO(newline="")
            writer = csv.writer(output)
            writer.writerow(EXPORT_HEADERS)
            for row in rows:
                # Neutralize spreadsheet formulas when untrusted data is opened in Excel.
                writer.writerow([("'" + row[f]) if row[f].startswith(("=", "+", "-", "@", "\t", "\r")) else row[f] for f in FIELDS])
            binary = io.BytesIO(output.getvalue().encode("utf-8-sig"))
            return send_file(binary, mimetype="text/csv; charset=utf-8", as_attachment=True, download_name=filename)
        book = Workbook()
        sheet = book.active
        sheet.title = "Officers"
        sheet.append(EXPORT_HEADERS)
        for row in rows:
            sheet.append([row[f] for f in FIELDS])
            for cell in sheet[sheet.max_row]:
                cell.data_type = "s"
        for cell in sheet[1]:
            cell.font = Font(bold=True, color="FFFFFF", size=11)
            cell.fill = PatternFill("solid", fgColor="2563EB")
            cell.alignment = Alignment(vertical="center")
        sheet.row_dimensions[1].height = 28
        for column, width in zip("ABCDEFGHI", [25, 18, 20, 25, 15, 38, 22, 18, 60]):
            sheet.column_dimensions[column].width = width
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = f"A1:I{max(1, sheet.max_row)}"
        if rows:
            table = Table(displayName="OfficerDirectory", ref=f"A1:I{sheet.max_row}")
            table.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
            sheet.add_table(table)
        output = io.BytesIO()
        book.save(output)
        output.seek(0)
        return send_file(output, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", as_attachment=True, download_name=filename)

    @app.get("/")
    def index():
        return send_from_directory(ROOT / "web", "index.html")

    @app.get("/<path:path>")
    def spa(path):
        if path.startswith("api/"):
            return jsonify(error="Endpoint not found."), 404
        full = (ROOT / "web" / path).resolve()
        if full.is_relative_to((ROOT / "web").resolve()) and full.is_file():
            return send_from_directory(ROOT / "web", path)
        return send_from_directory(ROOT / "web", "index.html")

    return app


def main():
    from waitress import serve
    os.umask(0o077)
    app = create_app()
    port = int(os.environ.get("PORT", 3000))
    if not 1 <= port <= 65535:
        raise RuntimeError("PORT must be between 1 and 65535.")
    proxy_options = {}
    trusted_proxy = os.environ.get("TRUSTED_PROXY")
    if trusted_proxy:
        # Enable only behind a controlled ingress/reverse proxy. Never trust
        # arbitrary forwarded headers on a directly exposed VPS listener.
        proxy_options = {
            "trusted_proxy": trusted_proxy,
            "trusted_proxy_count": 1,
            "trusted_proxy_headers": {"x-forwarded-for", "x-forwarded-proto", "x-forwarded-host", "x-forwarded-port"},
        }
    print(f"Roster is running on 0.0.0.0:{port} ({app.config['ROSTER_ENV']})", flush=True)
    serve(
        app, host="0.0.0.0", port=port, threads=8, expose_tracebacks=False,
        max_request_body_size=app.config["MAX_CONTENT_LENGTH"], max_request_header_size=16384,
        connection_limit=200, channel_timeout=30, cleanup_interval=10, ident="roster",
        **proxy_options,
    )


if __name__ == "__main__":
    main()
