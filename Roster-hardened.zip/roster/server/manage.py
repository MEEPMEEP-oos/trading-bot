"""Private owner-only maintenance. No backup/restore/reset endpoint is public.

Usage:
  python -m server.manage backup /data/backups/roster.sqlite3
  python -m server.manage restore /data/import.sqlite3 --database /data/new.sqlite3
  python -m server.manage set-password
"""
from __future__ import annotations

import argparse
import getpass
import json
import os
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path

from werkzeug.security import generate_password_hash

if __package__:
    from .app import PASSWORD_RULE, valid_password
else:
    from app import PASSWORD_RULE, valid_password

ROOT = Path(__file__).resolve().parent.parent
REQUIRED_TABLES = {"settings", "officers", "sessions", "activity"}


def checked_database(path: Path):
    path = path.expanduser().resolve()
    if not path.is_file():
        raise ValueError("Database not found. Check ROSTER_DB or --database.")
    connection = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=15)
    try:
        tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not REQUIRED_TABLES.issubset(tables):
            raise ValueError("The source is not a Roster database.")
        if connection.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise ValueError("The source database did not pass its integrity check.")
        return connection
    except Exception:
        connection.close()
        raise


def new_destination(path: Path):
    path = path.expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
    except FileExistsError:
        raise ValueError("Destination already exists. Choose a new filename; live data is never overwritten.")
    os.close(fd)
    return path


def backup_database(database: Path, destination: Path):
    source = checked_database(database)
    target_path = None
    try:
        target_path = new_destination(destination)
        target = sqlite3.connect(target_path, timeout=15)
        try:
            # SQLite's backup API includes a consistent snapshot of committed
            # WAL transactions; copying a live .sqlite3 file alone does not.
            source.backup(target)
        finally:
            target.close()
        return target_path
    except Exception:
        if target_path is not None:
            target_path.unlink(missing_ok=True)
        raise
    finally:
        source.close()


def restore_database(source_path: Path, destination: Path):
    # Never replace an in-use database. Restore to a NEW path, then configure
    # ROSTER_DB to that path and restart/redeploy the service.
    restored = backup_database(source_path, destination)
    connection = sqlite3.connect(restored, timeout=15)
    try:
        with connection:
            connection.execute("DELETE FROM sessions")
            connection.execute(
                "INSERT INTO activity VALUES(?,?,?,?,?,?,?)",
                (str(uuid.uuid4()), "workspace", "Workspace restored from a private database backup.", None, json.dumps({}), "System", datetime.now(timezone.utc).isoformat()),
            )
    finally:
        connection.close()
    return restored


def set_password(database: Path, password: str):
    if not valid_password(password):
        raise ValueError(PASSWORD_RULE)
    source = checked_database(database)
    source.close()
    connection = sqlite3.connect(database, timeout=15)
    try:
        with connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                "INSERT INTO settings(key,value) VALUES('admin_password',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (generate_password_hash(password),),
            )
            connection.execute("DELETE FROM sessions")
            connection.execute(
                "INSERT INTO activity VALUES(?,?,?,?,?,?,?)",
                (str(uuid.uuid4()), "security", "The administrator password was reset by the workspace owner.", None, json.dumps({}), "System", datetime.now(timezone.utc).isoformat()),
            )
    finally:
        connection.close()


def use_database_owner(database: Path):
    """Keep SQLite journals owned by the web account when a Docker shell is root."""
    if os.geteuid() == 0 and database.is_file():
        owner = database.stat()
        if owner.st_uid != 0:
            os.setgroups([])
            os.setgid(owner.st_gid)
            os.setuid(owner.st_uid)


def main():
    parser = argparse.ArgumentParser(description="Private Roster database maintenance")
    commands = parser.add_subparsers(dest="command", required=True)
    default_database = os.environ.get("ROSTER_DB", ROOT / "data" / "roster.sqlite3")
    backup = commands.add_parser("backup", help="Create a consistent, private database snapshot")
    backup.add_argument("destination", type=Path)
    backup.add_argument("--database", type=Path, default=Path(default_database))
    restore = commands.add_parser("restore", help="Restore a snapshot to a NEW database file")
    restore.add_argument("source", type=Path)
    restore.add_argument("--database", type=Path, default=Path(default_database))
    reset = commands.add_parser("set-password", help="Reset the admin password and revoke all sessions")
    reset.add_argument("--database", type=Path, default=Path(default_database))
    args = parser.parse_args()
    os.umask(0o077)
    try:
        if args.command == "backup":
            use_database_owner(args.database)
            result = backup_database(args.database, args.destination)
            print(f"Private backup saved: {result}")
            print("This contains officer data and password hashes. Do not commit or publicly share it.")
        elif args.command == "restore":
            result = restore_database(args.source, args.database)
            print(f"Restored to: {result}")
            print("Existing admin credentials are preserved; old sessions were revoked. Set ROSTER_DB to this new path and restart.")
        else:
            use_database_owner(args.database)
            password = getpass.getpass("New admin password (at least 12 characters): ")
            confirmation = getpass.getpass("Confirm password: ")
            if password != confirmation:
                raise ValueError("Passwords did not match. Nothing was changed.")
            set_password(args.database, password)
            print("Administrator password updated. All existing sessions have been signed out.")
    except (ValueError, sqlite3.Error, OSError) as error:
        parser.error(str(error))


if __name__ == "__main__":
    main()
