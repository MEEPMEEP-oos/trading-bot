"""Roster application, deployment launcher, and private database administration."""
