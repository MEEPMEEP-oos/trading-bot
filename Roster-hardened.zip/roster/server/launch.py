"""Container entrypoint: prepare a mounted data volume, then drop privileges.

Render/Railway volumes can arrive root-owned. Only the dedicated database
folder and SQLite sidecar files are touched. The HTTP process never runs as root.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path


def prepare_storage(database: Path, uid: int = 10001, gid: int = 10001):
    database = database.expanduser()
    if database.is_symlink():
        raise RuntimeError("ROSTER_DB must be a regular file, not a symbolic link.")
    directory = database.parent.resolve()
    if directory in {Path("/"), Path("/app"), Path("/etc"), Path("/home"), Path("/var")}:
        raise RuntimeError("Use a dedicated persistent data directory for ROSTER_DB.")
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    if os.geteuid() == 0:
        os.chmod(directory, 0o700)
        os.chown(directory, uid, gid)
        for suffix in ["", "-wal", "-shm"]:
            candidate = Path(str(database) + suffix)
            if candidate.is_symlink():
                raise RuntimeError("SQLite files on the volume must not be symbolic links.")
            if candidate.exists():
                if not candidate.is_file():
                    raise RuntimeError("ROSTER_DB and its sidecars must be regular files.")
                os.chmod(candidate, 0o600)
                os.chown(candidate, uid, gid)
        os.setgroups([])
        os.setgid(gid)
        os.setuid(uid)
    if not os.access(directory, os.W_OK):
        raise RuntimeError("The persistent database directory is not writable by the web process.")
    os.umask(0o077)


def main():
    database = Path(os.environ.get("ROSTER_DB", "/data/roster.sqlite3"))
    prepare_storage(database)
    # Replace the launcher: signals from the hosting provider reach Waitress.
    os.execv(sys.executable, [sys.executable, "-m", "server.app"])


if __name__ == "__main__":
    main()
