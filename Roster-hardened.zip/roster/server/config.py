"""Validated environment settings for local previews and durable deployments."""
from __future__ import annotations

import os
from pathlib import Path


def boolean_env(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    normalized = value.strip().lower()
    if normalized in {"true", "1", "yes", "on"}:
        return True
    if normalized in {"false", "0", "no", "off"}:
        return False
    raise RuntimeError(f"{name} must be true or false.")


def runtime_config(root: Path, database_path=None) -> dict:
    mode = os.environ.get("ROSTER_ENV", "development").strip().lower()
    mode = {"dev": "development", "prod": "production"}.get(mode, mode)
    if mode not in {"development", "test", "production"}:
        raise RuntimeError("ROSTER_ENV must be development, test, or production.")
    production = mode == "production"
    secure = boolean_env("COOKIE_SECURE", production)
    partitioned = boolean_env("COOKIE_PARTITIONED", False)
    raw_same_site = os.environ.get("COOKIE_SAMESITE", "Lax").strip().lower()
    same_site = {"lax": "Lax", "strict": "Strict", "none": "None"}.get(raw_same_site)
    if same_site is None:
        raise RuntimeError("COOKIE_SAMESITE must be Lax, Strict, or None.")
    if (same_site == "None" or partitioned) and not secure:
        raise RuntimeError("SameSite=None and partitioned cookies require COOKIE_SECURE=true.")
    ancestors = os.environ.get("FRAME_ANCESTORS", "'self'").strip()
    if ancestors in {"self", "none"}:
        ancestors = "'" + ancestors + "'"
    if not ancestors or any(c in ancestors for c in ["\r", "\n", ";"]):
        raise RuntimeError("FRAME_ANCESTORS must be a valid CSP source list without newlines or semicolons.")
    database = Path(database_path or os.environ.get("ROSTER_DB", root / "data" / "roster.sqlite3")).expanduser().resolve()
    hosts = [h.strip().lower() for h in os.environ.get("ROSTER_ALLOWED_HOSTS", "").split(",") if h.strip()]
    if any(any(c in h for c in "/\\ \t") for h in hosts):
        raise RuntimeError("ROSTER_ALLOWED_HOSTS must be a comma-separated list of host names, without schemes or paths.")
    config = {
        "PRODUCTION": production,
        # Officer contact details, notes, history and exports are private by
        # default in production. Set ROSTER_PUBLIC_VIEW=true to publish them.
        "PUBLIC_VIEW": boolean_env("ROSTER_PUBLIC_VIEW", not production),
        "ROSTER_ENV": mode,
        "DATABASE": str(database),
        "SEED_DEMO": boolean_env("ROSTER_SEED_DEMO", not production),
        "COOKIE_SECURE": secure,
        "COOKIE_PARTITIONED": partitioned,
        "COOKIE_SAMESITE": same_site,
        "FRAME_ANCESTORS": ancestors,
        "MAX_CONTENT_LENGTH": 65536,
    }
    if hosts:
        # Rejects requests whose Host header is not one of your own domains
        # (blocks host-header poisoning and DNS-rebinding).
        config["TRUSTED_HOSTS"] = hosts
    return config
