# Roster verification — deployment-ready v1.1

Verified 2026-10-01. All destructive tests used separate disposable databases, never the live preview database.

## Results actually executed

| Check | Result |
|---|---|
| Production frontend build (`npm run build`) | PASS |
| API and deployment integration (`pytest`) | **72/72 PASS**: 36 API + 36 deployment/maintenance/configuration checks |
| Existing end-to-end browser suite | **19/19 PASS**, including embedded password-protected editing |
| Read-only accessibility audits | **9 screens, zero automatic violations** |
| Fresh empty production directory accessibility | **Zero automatic violations** |
| Production browser flow | PASS: preconfigured login, protected add, refresh, Excel download, delete, mobile width, no JS/CSP errors |
| Actual production-mode process restart | PASS: persisted record and configured administrator, even after removing the bootstrap password from the restarted process |
| Post-restart editing, CSV, genuine `.xlsx`, deletion | PASS; CSV parsed and workbook opened with openpyxl |
| Persistent preview data | Existing database retained; 24 fictional officers at verification time; no reset/admin changes performed |
| Render blueprint | PASS against a downloaded snapshot of Render's official JSON Schema |
| GitHub workflow | YAML and all embedded shell scripts parsed successfully |
| Dependency audit | `npm audit --omit=dev`: zero reported vulnerabilities |

Tested runtime: Python 3.13, Flask 3.1.3, Waitress 3.0.2, openpyxl 3.1.5, Node 20.20.2 (local build), Vite 7.3.6, Playwright Chromium. Docker/CI frontend builds use Node 22.

## What the added deployment checks cover

- New production databases contain no fictional seeds unless explicitly requested.
- Bootstrap password is privately configured, scrypt-hashed, absent from app config/public output, and never overwritten on restart.
- Startup rejects missing/invalid initial credentials; public password setup is disabled in production.
- Password changes survive a redeploy even when the old bootstrap environment value remains configured.
- Existing development data/admin configuration survives switching to production mode.
- Secure standalone cookies, CSP/HSTS/permissions headers, optional local HTTP testing, and frame-compatible development previews.
- Invalid modes, booleans, cookie combinations, and injected frame-header syntax fail clearly.
- Environment-selected database paths and opt-in demo seeding.
- Consistent private SQLite backups, integrity checks, safe refusal to overwrite, restore preserving data/credentials and revoking sessions.
- Private owner password reset revoking all sessions without deleting officers.
- Container launcher volume preparation, privilege-drop call order, symlink refusal, and dedicated-folder guards.
- Persistent volume/disk mappings, one Render instance, private password fields, and Docker-context exclusions for data/secrets.

The empty production screen initially exposed a skipped heading level. Its empty-state headings were changed to semantic `h2` headings; production accessibility then passed without changing the visual design.

## Original application checks rerun

The 36 API tests cover authorization, setup/login/logout, validation, duplicate badges, CRUD, sorting in both directions, combined filtering, pagination, CSV/XLSX contents and formula safety, stale-edit conflicts, bulk deletion, session expiry, password changes, rate limits, cookie attributes, and persistence.

The 19 browser checks cover public search/sort/filter/columns/pagination, protected setup/add/edit/remove/bulk removal, real file downloads, refresh persistence, password changes and incorrect passwords, overview/activity/exports, profiles, keyboard search/help, mobile navigation, and cross-site embedded admin actions. No JavaScript page errors or server 5xx errors were observed.

Accessibility audited the settled directory, admin dialog, overview, activity, exports, filters, officer profile, help, and mobile directory. Mobile document width was 390 px at a 390 px viewport. These automatic checks supplement rather than replace manual accessibility testing.

## Important verification limits

**No Docker/Podman engine is available in this workspace, so an actual container image build/run was not executed here.** Configuration and launcher behavior were tested, and the equivalent native production runtime was exercised. The included GitHub Actions workflow will build the real image, verify HTTP-process UID 10001, test a persistent volume across a container restart, and run production browser checks when the repository is pushed and Actions is enabled.

**No hosting account was connected and no permanent public deployment was created.** Follow DEPLOY.md to deploy, review provider charges, configure your own password, and verify the actual hosted service. The workspace live preview is not permanent hosting.

Durability requires keeping the attached disk/volume. Backups should be stored off-host and periodically restored to a separate path. SQLite supports the intended single-instance directory, not horizontal multi-instance scaling.

## Deliverable hygiene

The deployment archive includes source, built frontend, Docker/Compose/Render configuration, CI, tests, and documentation. It excludes the live database, real credentials, `.env`, installed dependencies, browser artifacts, and temporary test databases. Frontend dependency notices and the Inter font license are included.

## Security hardening pass (2026-10-09)

- Production is private by default (`ROSTER_PUBLIC_VIEW=false`); sign-in gate in the UI.
- 87 API/deployment tests pass; 19 development and 3 production browser flows pass (incl. accessibility audit, CSP).
- `pip-audit` and `npm audit`: 0 known vulnerabilities. `bandit`: 0 high (remaining notes are allow-listed SQL column names).
- Re-run the Docker image checks in CI (`.github/workflows/ci.yml`), which now also runs a dependency/static audit job.
